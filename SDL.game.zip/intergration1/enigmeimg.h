#ifndef ENIGMEIMG_H_INCLUDED
#define ENIGMEIMG_H_INCLUDED

#include <SDL/SDL.h> //biblio sdl
#include <SDL/SDL_ttf.h> //biblio texte
#include <SDL/SDL_mixer.h> //biblio sound
#include <SDL/SDL_image.h> //biblio image



typedef struct
{
	SDL_Surface *rep1,*rep2,*rep3,*rep1_1,*rep2_1,*rep3_1, *rep1_1_def,*rep2_1_def,*rep3_1_def;
	SDL_Rect img_p, rep1_pos,rep2_pos,rep3_pos,rep1_pos_1,rep2_pos_1,rep3_pos_1; 
	SDL_Surface *img_corr1,*img_corr2,*img_corr3, *img_faux;
	SDL_Rect img_reponse_pos;
	SDL_Surface *img_back;
	SDL_Rect img_back_pos;
	//int resultat;
	//variable choix c le choix du joueur
	//res c la solution du l enigme
	int alea,res,choix,choix_prec,mouse;
	//ques
	char ques[100];

}eng_img;

//structure texte

typedef struct
{
	TTF_Font *font;
	SDL_Color textColor;
	SDL_Surface *surfaceTexte,*a,*b,*c;
	SDL_Rect position,ap,bp,cp; //pos
	char texte[50];
}texte;

int enigme_image();
//-------------fonctions-------------
void draw_image(SDL_Surface *img, SDL_Surface *screen, int x, int y);
void init_enigme_img(eng_img *ei);
void animation(SDL_Surface *screen);
void animation_sad(SDL_Surface *screen);
void affich_enigme(eng_img *ei,SDL_Surface *screen, int *test1, int *test2, int *test3);
void process_input(eng_img *ei, SDL_Surface *screen, int *test1, int *test2, int *test3);
void resolu_enigme(eng_img *ei,SDL_Surface *screen, int *test1, int *test2, int *test3);//comparez les choix et les bonnes reponses
void generation_alea(eng_img *ei);//generation aleatoire des reponses et questions a partir du fichier
void sous_menu_sauvegarde(eng_img ei); //2 fonctions: chargees donnees et sauvegarder donnees
void animer(eng_img *ei, SDL_Surface *screen, int x, int y, int *test1, int *test2, int *test3);
void animation_story(SDL_Surface *screen);
void cineee(SDL_Surface *screen);

//------display-----
void display(texte t,eng_img *ei,SDL_Surface *screen);

//-------texte------
void initText(texte *t);
void FreeText(texte A);

//------liberer------
void liberer(eng_img ei);

#endif





