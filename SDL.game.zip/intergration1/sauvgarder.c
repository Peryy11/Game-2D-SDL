
#include "sauvgarder.h"

void sauvegarder (Personne P,Background b) {
FILE *fichier;
save s;
s.P=P;
s.b=b;
fichier=fopen("save_perso.bin","wb");
if (fichier != NULL)
{
    fwrite(&s,sizeof(save),1,fichier);
    printf("!!!!!!!!!!!! game saved\n");
}
else printf("!!!!!!!!!!!   failed");


fclose(fichier);

}

void charger (Personne *P,Background *b )
{

    FILE *fichier;
    save s;
    fichier=fopen("save_perso.bin","rb");
    fread(&s,sizeof(save),1,fichier);
    fclose(fichier);


   
	P->acceleration=s.P.acceleration;
	
    	P->direction=s.P.direction;
	P->position=s.P.position;
	P->nbr_frame=s.P.nbr_frame;
	P->vitesse = s.P.vitesse ;
	P->acceleration = s.P.acceleration ;
	P->vitesse_saut = s.P.vitesse_saut ;
	memcpy(P->images,s.P.images,2*4*sizeof(SDL_Surface));

   
    b->offset_x=s.b.offset_x;
    b->offset_y=s.b.offset_y;
    b->offset_val=s.b.offset_val;
    b->srect=s.b.srect;
    b->dsrect=s.b.dsrect;

    

    printf("perso et background chargés\n");


}

