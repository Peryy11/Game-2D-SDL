#ifndef perso_H_INCLUDED
#define perso_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <stdbool.h>
#include <math.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>
#include <time.h>

typedef struct Personne
{
    SDL_Surface *images[2][8]; 
    SDL_Rect position;
    int direction;
    int nbr_frame;
    double vitesse,acceleration,vitesse_saut;
    float gravity;
    float velocity_y;
	int is_jumping;
    double dx;
    int ground,up,jump;
int num;

}Personne;


void initPerso(Personne *p);
void initPerso2(Personne *p);
void afficherPerso(Personne p, SDL_Surface * screen);
void deplacerPerso (Personne *p,Uint32 dt);
void animerPerso (Personne* p);
void saut (Personne* p) ;
void libererperso(Personne p);
void saut_Parabolique(Personne *P, Uint32 dt, int posx_absolu, int posy_absolu)  ;

void draw_tag(Personne *p, SDL_Surface *screen);
void render_text(SDL_Surface *surface, TTF_Font *font,  const char *text, SDL_Color color, int x, int y);
void choice_player(Personne *p, SDL_Surface *screen, TTF_Font *font) ;
void draw_image1(SDL_Surface *img, SDL_Surface *screen, int x, int y);

SDL_Surface* load_image(const char* filename);
void draw_imagePAUSE(SDL_Surface* image, int x, int y);

#endif
