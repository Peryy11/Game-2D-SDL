#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <ctype.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <string.h>
#include <SDL/SDL_mixer.h>
#include <time.h>
#include "perso.h"
#include "function.h"
#include "es.h"
#include "enigmeimg.h"
#include "enigme.h"
#include "minimap.h"
#include "main.h"
#include "tictactoe.h"


#define WIDTH 800
#define HEIGHT 600



TTF_Font *font=NULL;

// Load an image from a file and return a surface
SDL_Surface* load_image(const char* filename){
    SDL_Surface* image = IMG_Load(filename);
    if (!image) {
        printf("Error loading image: %s", SDL_GetError());
        exit(1);
    }
    return image;
}
// Draw an image to the screen at the specified position
void draw_imagePAUSE(SDL_Surface* image, int x, int y){
    SDL_Rect dest_rect = { x, y, 0, 0 };
    SDL_BlitSurface(image, NULL, SDL_GetVideoSurface(), &dest_rect);
}



  
//////////////////////////////////////////////////fin boucle////////////:

void initPerso(Personne *p){
font = TTF_OpenFont("font.ttf",20);
int i,j;
    char nom_image[30];
    p->acceleration=0;
    p->direction=0;
    p->nbr_frame=0;
    p->up=0;
    p->jump=0;
    p->ground=370;
    p->position.x=0;
    p->position.y=20;
    p->position.w=20;
    p->position.h=10;

    p->vitesse=0;
    p->vitesse_saut=0;

 
    for ( i = 0; i < 2; i++)
    {
        for ( j = 0; j < 8; j++)
        {  
            sprintf(nom_image,"p/animation%d%d.png",i,j);
            p->images[i][j]=IMG_Load(nom_image);
		
	if(p->images[i][j]==NULL)
	{
	printf("unable to load backgroud image %s \n",SDL_GetError());
	return;
	}
        }
       
    }
   
}


void initPerso2(Personne *p){
int i,j;
    char nom_image[30];
    p->acceleration=0;
    p->direction=0;
    p->nbr_frame=0;
    p->up=0;
    p->jump=0;
    p->ground=300;
    p->position.x=650;
    p->position.y=1000;
    p->position.w=10;
    p->position.h=50;

    p->vitesse=0;
    p->vitesse_saut=0;

 
    for ( i = 0; i < 2; i++)
    {
        for ( j = 0; j < 8; j++)
        {  
            sprintf(nom_image,"p/animation%d%d.png",i,j);
            p->images[i][j]=IMG_Load(nom_image);
		
	if(p->images[i][j]==NULL)
	{
	printf("unable to load backgroud image %s \n",SDL_GetError());
	return;
	}
        }
       
    }
   
}

void afficherPerso(Personne p, SDL_Surface * screen){
    SDL_BlitSurface(p.images[p.direction][p.nbr_frame],NULL,screen,&p.position);
}


void deplacerPerso (Personne *p,Uint32 dt)
{

p->dx = 0.5 * p->acceleration * dt * dt + p->vitesse * dt ;

//printf("acceleration:%f",p->acceleration);
//printf("vitesse:%f",p->vitesse);
/*
    if (p->direction==0 && p->position.x < 1000)//mvt droite
    {
	p->position.x = p->position.x +p->dx ;        
    }
*/
	// A changer
	if (p->direction==0 && p->position.x + 360 < 600) {
		p->position.x = p->position.x +p->dx ;
	}
		
	if (p->direction==1 && p->position.x > 0) {
		p->position.x = p->position.x - p->dx;
	}
 
}



void animerPerso (Personne* p){

  //printf("%d\n",p->nbr_frame);
  (p->nbr_frame)++;
    if (p->nbr_frame == 8)
{
 	p->nbr_frame=0;
}
if ((p->vitesse==0) && ((p->direction == 0) || (p->direction == 1)))
{
p->nbr_frame= 0;
}
}



void saut_Parabolique(Personne *P, Uint32 dt, int posx_absolu, int posy_absolu) 
{
        P->position.x += (int)(0.25 * dt / 500.0);
        double a = -0.04;
        double c = 50;
        P->position.y = (int)(a * P->position.x * P->position.x + c);

        
        if (P->position.y >= posy_absolu) 
	{
            P->position.y = posy_absolu;
            P->jump = 0;

        }

    int posx_relatif = P->position.x - posx_absolu;
    int posy_relatif = P->position.y - posy_absolu;
    P->position.x = posx_absolu + posx_relatif;
    P->position.y = posy_absolu + posy_relatif;

}

void saut (Personne* p) 
{
    if (p->position.y == p->ground)
    {
       p->vitesse_saut=-60;
       p->up=1;
    }
   
}




void libererperso(Personne p)
{
int i,j;
    for ( i = 0; i < 2; i++)
    {
        for ( j = 0; j < 8; j++)
        {  
	    SDL_FreeSurface(p.images[i][j]);
        }
       
    }
   

}


void render_text(SDL_Surface *surface, TTF_Font *font,  const char *text, SDL_Color color, int x, int y)
{
	if (surface == NULL || font == NULL || text == NULL) {
    printf("error font");
    return;
}

	SDL_Rect titlepos;
	titlepos.x=x;
	titlepos.y=y;
	//title

	SDL_Surface *blended_text = TTF_RenderText_Blended(font, text, color);

    SDL_BlitSurface(blended_text, NULL, surface, &titlepos);

    SDL_FreeSurface(blended_text);
}




void draw_tag(Personne *p, SDL_Surface *screen)
{
         			SDL_Color color = {255, 255, 255};
    char buffer[20];


if(!font)
printf("Error: font is NULL\n");

    sprintf(buffer, "P%d", p->num);
    render_text(screen, font,
                buffer, color,
                p->position.x + p->images[0][0]->w / 4,
                p->position.y - 30);
}

void draw_image1(SDL_Surface *img, SDL_Surface *screen, int x, int y)
{
    if (img == NULL) {
        printf("Error: img is NULL\n");
        return;
    }
    
    SDL_Rect dsrect;
    dsrect.x = x;
    dsrect.y = y;
    dsrect.w = img->w;
    dsrect.h = img->h;
    
    SDL_BlitSurface(img, NULL, screen, &dsrect);
}


void choice_player(Personne *p, SDL_Surface *screen, TTF_Font *font) {
    SDL_Event event;
    int current_image = 1;
    SDL_Surface *image1 = IMG_Load("player_1.jpg");
    SDL_Surface *image2 = IMG_Load("player_2.png");
    int done = 0;
    int x = 0, y = 0;
    screen = SDL_SetVideoMode(600, 800, 32, SDL_HWSURFACE);

    if (!image1 || !image2) {
        printf("Failed to load player images.\n");
        return;
    }

    draw_image1(image1, screen, x, y);
    SDL_Flip(screen);

    while (!done) {
        while (SDL_PollEvent(&event)) {
            switch (event.type) {
                case SDL_QUIT:
                    done = 1;
                    break;
                case SDL_KEYDOWN:
                    if (event.key.keysym.sym == SDLK_UP || event.key.keysym.sym == SDLK_DOWN) {
                        if (current_image == 1) {
                            draw_image1(image2, screen, x, y);
                            current_image = 2;
                        } else if (current_image == 2) {
                            draw_image1(image1, screen, x, y);
                            current_image = 1;
                        }
                        SDL_Flip(screen);
                    } else if (event.key.keysym.sym == SDLK_RETURN) {
                        if (current_image == 1) {
                            p->num = 1;
                        } else if (current_image == 2) {
                            p->num = 2;
                        }
                        done = 1;
                    }
                    break;
            }
        }
    }

    SDL_FreeSurface(image1);
    SDL_FreeSurface(image2);
    TTF_CloseFont(font); // Add this line to close the font resource
}


