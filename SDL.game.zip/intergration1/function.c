#include "function.h"
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <time.h>
#include <pthread.h> 
#include "perso.h"

Uint32 get_pixel(SDL_Surface *surface, int x, int y)
{
    int bpp = surface->format->BytesPerPixel;
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;
    switch (bpp) {
        case 1:
            return *p;
        case 2:
            return *(Uint16 *)p;
        case 3:
            if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
                return p[0] << 16 | p[1] << 8 | p[2];
            else
                return p[0] | p[1] << 8 | p[2] << 16;
        case 4:
            return *(Uint32 *)p;
        default:
            return 0;
    }
}

void init_background(Background *b, SDL_Surface *screen)
{
    b->img = IMG_Load("background.png");
    b->obstacle =IMG_Load("obstacle.png");
    b->offset_x = 0;
    b->offset_y = b->img->h - screen->h;
    b->offset_val = OFFSET_VAL;

    b->srect.x = 0;
    b->srect.y = 0;
    b->srect.w = screen->w;
    b->srect.h = screen->h;

    b->dsrect.x = 0;
    b->dsrect.y = 0;
    b->dsrect.w = b->img->w;
    b->dsrect.h = b->img->h;

    b->pause=IMG_Load("pause_button.png");
    b->pause_pos.x=650;
    b->pause_pos.y=0;
    b->pause_pos.w=138;
    b->pause_pos.h=138;

    b->score=IMG_Load("score_board.png");
    b->score_pos.x=50;
    b->score_pos.y=0;
    b->score_pos.w=590;
    b->score_pos.h=659;

    pthread_t thread;
    int rc = pthread_create(&thread, NULL, (void *(*)(void *)) animate_background, b);

    if (rc != 0) {
        fprintf(stderr, "Error: Failed to create animate_background thread\n");
        exit(EXIT_FAILURE);
    }
}


void init_background_level2(Background *b, SDL_Surface *screen)
{
    b->img = IMG_Load("background_lvl2.png");
    b->obstacle =IMG_Load("obstacle_lvl2.png");
    b->offset_x = 0;
    b->offset_y = b->img->h - screen->h;
    b->offset_val = OFFSET_VAL;

    b->srect.x = 0;
    b->srect.y = 0;
    b->srect.w = screen->w;
    b->srect.h = screen->h;

    b->dsrect.x = 0;
    b->dsrect.y = 0;
    b->dsrect.w = b->img->w;
    b->dsrect.h = b->img->h;

    b->pause=IMG_Load("pause_button.png");
    b->pause_pos.x=650;
    b->pause_pos.y=0;
    b->pause_pos.w=138;
    b->pause_pos.h=138;

    b->score=IMG_Load("score_board.png");
    b->score_pos.x=50;
    b->score_pos.y=0;
    b->score_pos.w=590;
    b->score_pos.h=659;

    pthread_t thread;
    int rc = pthread_create(&thread, NULL, (void *(*)(void *)) animate_background_lvl2, b);

    if (rc != 0) {
        fprintf(stderr, "Error: Failed to create animate_background_lvl2 thread\n");
        exit(EXIT_FAILURE);
    }
}



void init_background_level3(Background *b, SDL_Surface *screen)
{
    b->img = IMG_Load("background_lvl3.png");
    b->obstacle =IMG_Load("obstacle_lvl3.png");
    b->offset_x = 0;
    b->offset_y = b->img->h - screen->h;
    b->offset_val = OFFSET_VAL;

    b->srect.x = 0;
    b->srect.y = 0;
    b->srect.w = screen->w;
    b->srect.h = screen->h;

    b->dsrect.x = 0;
    b->dsrect.y = 0;
    b->dsrect.w = b->img->w;
    b->dsrect.h = b->img->h;

    b->pause=IMG_Load("pause_button.png");
    b->pause_pos.x=650;
    b->pause_pos.y=0;
    b->pause_pos.w=138;
    b->pause_pos.h=138;

    b->score=IMG_Load("score_board.png");
    b->score_pos.x=50;
    b->score_pos.y=0;
    b->score_pos.w=590;
    b->score_pos.h=659;

    pthread_t thread;
    int rc = pthread_create(&thread, NULL, (void *(*)(void *)) animate_background_lvl3, b);

    if (rc != 0) {
        fprintf(stderr, "Error: Failed to create animate_background_lvl3 thread\n");
        exit(EXIT_FAILURE);
    }
}






void afficher_menu_pause(Background *b, SDL_Surface *screen)
{
    SDL_BlitSurface(b->score, NULL, screen, &b->score_pos);
}

bool scrolling(SDL_Surface *screen, Background *b, int direction, int x, int y,int *anim) {

    switch (direction) {
        case 1:
            if (b->offset_x + b->offset_val < b->img->w - screen->w) {
                b->offset_x += b->offset_val;
            }
            else {
                b->offset_x = b->img->w - screen->w;
		*anim = 0; 
            }
            if (x + b->offset_val <= screen->w / 2) {
                x += b->offset_val;
            }


        break;

        case 2:
            if (b->offset_x - b->offset_val >= 0) {
                b->offset_x -= b->offset_val;
            }
            else {
                b->offset_x = 0;
            }
            if (x - b->offset_val >= screen->w / 2) {
                x -= b->offset_val;
            }
        break;

        
case 3:
            if (b->offset_y - b->offset_val >= 0) {
                b->offset_y -= b->offset_val;
            }
            else {
                b->offset_y = 0;
            }
            if (y - b->offset_val >= screen->h / 2) {
                y -= b->offset_val;
            }
        break;

        case 4:
            if (b->offset_y + b->offset_val < b->img->h - screen->h) {
                b->offset_y += b->offset_val;
            }
            else {
                b->offset_y = b->img->h - screen->h;
            }
            if (y + b->offset_val <= screen->h / 2) {
                y += b->offset_val;
            }
        break;

        default:
            return false;
    }
    return true;
}

void draw_background(Background *b, SDL_Surface *screen, int x, int y,vie *tli,int *anim) {
    b->srect.x = b->offset_x % b->img->w;
    b->srect.y = b->offset_y % b->img->h;
if ((*anim)=1)
    SDL_BlitSurface(b->img, &b->srect, screen, &b->dsrect);
else{
SDL_Surface* image = IMG_Load("background_win1.png");
    SDL_BlitSurface(image, &b->srect, screen, &b->dsrect);
}

    SDL_BlitSurface(b->pause, NULL,screen,&b->pause_pos);
    
  SDL_BlitSurface(tli->images[tli->current_image], NULL, screen, &tli->position);
}

void draw_background_lvl2(Background *b, SDL_Surface *screen, int x, int y,vie *tli,int *anim) {
    b->srect.x = b->offset_x % b->img->w;
    b->srect.y = b->offset_y % b->img->h;
if ((*anim)=1)
    SDL_BlitSurface(b->img, &b->srect, screen, &b->dsrect);
else{
SDL_Surface* image = IMG_Load("background_win2.png");
    SDL_BlitSurface(image, &b->srect, screen, &b->dsrect);
}


    SDL_BlitSurface(b->pause, NULL,screen,&b->pause_pos);
    
  SDL_BlitSurface(tli->images[tli->current_image], NULL, screen, &tli->position);
}

void draw_background_lvl3(Background *b, SDL_Surface *screen, int x, int y,vie *tli,int *anim) {
    b->srect.x = b->offset_x % b->img->w;
    b->srect.y = b->offset_y % b->img->h;
if ((*anim)=1)
    SDL_BlitSurface(b->img, &b->srect, screen, &b->dsrect);
else{
SDL_Surface* image = IMG_Load("background_win.png");
    SDL_BlitSurface(image, &b->srect, screen, &b->dsrect);
}


    SDL_BlitSurface(b->pause, NULL,screen,&b->pause_pos);
    
  SDL_BlitSurface(tli->images[tli->current_image], NULL, screen, &tli->position);
}

void animate_background(Background *b) {
    int delay = 500; 
    int i = 0;
    while (true) {
        switch (i) {
            case 0:
                b->img = IMG_Load("background_ani1.png");
                break;
            case 1:
                b->img = IMG_Load("background_ani2.png");
                break;
            case 2:
                b->img = IMG_Load("background_ani3.png");
                break;
            default:
                break;
        }
        i = (i + 1) % 3; 

        SDL_Delay(delay);
        delay = (rand() % 1000) + 500;
	
    }

}



void animate_background_lvl2(Background *b) {
    int delay = 500; 
    int i = 0;
    while (true) {
        switch (i) {
            case 0:
                b->img = IMG_Load("background_lvl2_ani1.png");
                break;
            case 1:
                b->img = IMG_Load("background_lvl2.png");
                break;
            case 2:
                b->img = IMG_Load("background_lvl2_ani1.png");
                break;
            default:
                break;
        }
        i = (i + 1) % 3; 

        SDL_Delay(delay);
        delay = (rand() % 1000) + 500;
	
    }

}




void animate_background_lvl3(Background *b) {
    int delay = 500; 
    int i = 0;
    while (true) {
        switch (i) {
            case 0:
                b->img = IMG_Load("background_lvl3_ani1.png");
                break;
            case 1:
                b->img = IMG_Load("background_lvl3_ani2.png");
                break;
            case 2:
                b->img = IMG_Load("background_lvl3_ani3.png");
                break;
		case 3:
                b->img = IMG_Load("background_lvl3_ani4.png");
                break;
            default:
                break;
        }
        i = (i + 1) % 4; 

        SDL_Delay(delay);
        delay = (rand() % 1000) + 500;
	
    }

}

void init_top_left_image(vie *tli, SDL_Surface *screen)
{
     tli->current_image = 0;
    tli->images[0] = IMG_Load("vie1.png");
    tli->images[1] = IMG_Load("vie2.png");
    tli->images[2] = IMG_Load("vie3.png");
    tli->images[3] = IMG_Load("vie4.png");
    tli->images[4] = IMG_Load("vie5.png");
    tli->position.x = 10;
    tli->position.y = 10;
    tli->position.w = tli->images[0]->w;
    tli->position.h = tli->images[0]->h;
 }
 void score_menu(imgscore *tli, SDL_Surface *screen)
 {
     tli->current_image = 0;
    tli->img[0] = IMG_Load("pause_button.png");
    tli->position.x = 800;

    tli->position.y = 600;
    tli->position.w = tli->img[0]->w;
    tli->position.h = tli->img[0]->h;
 }
void initialiser_score(score *s)
{
 s->texte = NULL; 
 s->position.x=400;
 s->position.y=100;
 s->police = NULL;
 s->police = TTF_OpenFont("police.ttf", 25);
 strcpy( s->entree,"");
 (s->secondesEcoulees)=0;
time(&(s->t1));
}
void afficher_score(score *s, SDL_Surface *screen)
{
 SDL_Color couleurn= {255, 255, 255};//blanc
 time(&(s->t2));// temps actuel
 s->secondesEcoulees = s->t2 - s->t1;
 s->sc= ((s->secondesEcoulees)%60*151);
 sprintf(s->entree,"SCORE : %02d",s->sc);
 s->texte = TTF_RenderUTF8_Solid(s->police,s->entree, couleurn);
 SDL_BlitSurface(s->texte, NULL,screen, &(s->position)); /* Blit du texte */
}


