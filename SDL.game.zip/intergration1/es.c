#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include "es.h"
#include <time.h>
#include "perso.h"




void initEnnemi(Ennemi *e, char* trajet, int x, int y, int a, int b, int h, int w, int x1, int y1,int pas, int range, int vitesse, int vie)
{
	e->sheet.img = IMG_Load(trajet);
	if (e->sheet.img == NULL)
	{
		printf("Unable to load background image %s\n", SDL_GetError());
	}
	
	e->sheet.posscreen.x = x;
	e->sheet.posscreen.y = y;
	e->sheet.posdisplay.x = a;
	e->sheet.posdisplay.y = b;
	e->sheet.posdisplay.h = h;
	e->pos.h=h;
	e->pos.w=w;
	e->sheet.posdisplay.w = w;
	e->pos.x=x1;
	e->xi=x1;
	e->pos.y=y1;
	e->yi=y1;
	e->direction=rand()%2+2;
	e->pas=pas;
	e->range=range;
	e->marche=5;
	e->vitesse=vitesse;
	e->nb_vie=vie;
	e->etat_animation=0;
}
void animerEnnemi(Ennemi *en, SDL_Surface *screen)
{
	Uint32 current_time = SDL_GetTicks();
  if (current_time - en->etat_animation < 100)
    return;
  en->sheet.posdisplay.y = (en->direction) * en->sheet.posdisplay.h;
  if (en->sheet.posdisplay.x <= en->marche * en->sheet.posdisplay.w) 
    en->sheet.posdisplay.x += en->sheet.posdisplay.w;
  else
    en->sheet.posdisplay.x = 0;
  en->etat_animation = current_time;
}

void musique()
{
	Mix_Music *mus;
	mus = Mix_LoadMUS("Robot Footsteps.mp3");
   Mix_PlayMusic(mus, 1);
}

void move(Ennemi *en, int pas, SDL_Rect pos)
{
	static Uint32 delay = 0;
	if(in_range(pos,*en)==1){
    follow(en,pos);
  }
	if(in_range(pos,*en)==0){
  	if (SDL_GetTicks() > delay){
    	switch (en->direction){
    	/*  case 0://down
    	    if (en->pas < pas && (en->pos.y+30 < HEIGHT * 4 && en->pos.y+30 < en->yi + (en->range / 2))){
    	      en->pas++;
    	      en->pos.y+= en->vitesse;
    	    }
    	    else{
    	      en->pas = 0;
    	      en->direction=rand()%4;
    	      delay = SDL_GetTicks() + 100;
    	    }
    	    break;
    	  case 1://up
	  	    if (en->pas < pas && (en->pos.y > 0 && en->pos.y > en->yi - (en->range / 2))) {
    	      en->pas++;
    	      en->pos.y -= en->vitesse;
    	    }
    	    else{
    	      en->pas = 0;
    	      en->direction=rand()%4;
    	      delay = SDL_GetTicks() + 100;
    	    }
    	    break;*/
    	  case 2://left
    	    if (en->pas < pas && (en->pos.x > 0 && en->pos.x > en->xi - (en->range / 2))){
    	      en->pas++;
    	      en->pos.x -= en->vitesse;
    	    }
    	    else{
    	      en->pas = 0;
    	      en->direction=rand()%2+2;
    	      delay = SDL_GetTicks() + 100;
    	    }
    	    break;
    	  case 3://right
    	    if (en->pas < pas && (en->pos.x +30< 1000 * 3 && en->pos.x+30< en->xi + (en->range / 2))){
    	      en->pas++;
    	      en->pos.x += en->vitesse;
    	    }
    	    else{
    	      en->pas = 0;
    	      en->direction=rand()%2+2;
    	      delay = SDL_GetTicks() + 100;
    	    }
    	    break;
   		}
   	}
  }
}
int collisionBB(Ennemi e1, Personne p)
{
	if (e1.pos.x <= p.position.x+30 && e1.pos.x+30 >= p.position.x && e1.pos.y <= p.position.y+30 && e1.pos.y+30 >= p.position.y)
		return 0;
	else return -1;
}
void attack(Ennemi *e)
{
	e->sheet.posdisplay.y=(e->direction+4)*e->sheet.posdisplay.h;
	if (e->sheet.posdisplay.x <=3*e->sheet.posdisplay.w){
		e->sheet.posdisplay.x+=e->sheet.posdisplay.w;
		SDL_Delay(100);
	}
	else 
		e->sheet.posdisplay.x=0;
}

int in_range(SDL_Rect pos, Ennemi en)
{
  int h = 30, w = 30;
  if (pos.x < (en.xi + en.range / 2) && pos.x + w > (en.xi - en.range / 2) && pos.y < (en.yi + en.range / 2) && pos.y + h > (en.yi - en.range / 2))
    return 1;
  else
  	return 0;
}

void follow(Ennemi *en, SDL_Rect pos)
{
	if (en->pos.x+en->pos.w < pos.x) {
    en->direction = 7;
    en->pos.x += en->vitesse;
 	}
	if (en->pos.x > pos.x+pos.w) {
    en->direction = 5;
    en->pos.x -= en->vitesse;
  }
  if (en->pos.y+en->pos.h < pos.y) {
    en->pos.y += en->vitesse;
  }
  if (en->pos.y > pos.y+pos.h) {
    en->pos.y -= en->vitesse;
  }
}

void afficher(SDL_Surface *img, SDL_Surface *screen, int x, int y)
{
	SDL_Rect pos = {.x = x, y = y, .h=img->h, .w=img->w};
	SDL_BlitSurface(img, NULL, screen, NULL);
}
void reset(Ennemi *e)
{
	e->pos.x=e->xi;
	e->pos.y=e->yi;
}
