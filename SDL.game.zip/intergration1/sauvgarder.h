
#ifndef sauvegarde_H_INCLUDED
#define sauvegarde_H_INCLUDED
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "perso.h"
#include "function.h"
//#include "Personne.h"
//#include "background.h"


/*typedef struct Personne
{
    SDL_Surface *images[2][6];
    SDL_Rect position;
    int direction;
    int nbr_frame;
    double vitesse,acceleration,vitesse_saut;
    double dx;
    int ground,up,jump;

}Personne;*/




/*typedef struct
{
int offset_x;
int offset_y;
int offset_val;
SDL_Rect srect;
SDL_Rect dsrect;
SDL_Surface *img;
SDL_Surface *obstacle;
}Background;
*/


typedef struct save
{
  
  Personne P;
  Background b;
}save;



void sauvegarder (Personne p,Background b) ; 
void charger (Personne *p,Background *b);
#endif

