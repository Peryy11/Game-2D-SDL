#include "minimap.h"
	#include <stdio.h>
	#include <stdlib.h>
	#include <SDL/SDL.h>
	#include <SDL/SDL_mixer.h>
	#include <SDL/SDL_image.h>
	#include <SDL/SDL_ttf.h>
	#include <string.h>

	
	
	void init_map (minimap *m)
	{
         
         m->map = IMG_Load("LVL11.png");
	 //m->masque= IMG_Load("obstacle.png");
	 m->minijoueur = IMG_Load("miniperso.png");
	 m->positionmap.x =230;
	 m->positionmap.y =20;
	 m->positionminijoueur.x =0;
	 m->positionminijoueur.y =0;
	 /*Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS,1024);
	 Mix_Music *music;
	 music=Mix_LoadMUS("music.mp3");
	 Mix_PlayMusic(music,-1);*/
	}
        void init_map2 (minimap *m)
	{
         
         m->map = IMG_Load("lvl22.png");
	 //m->masque= IMG_Load("obstacle.png");
	 m->minijoueur = IMG_Load("miniperso.png");
	 m->positionmap.x =230;
	 m->positionmap.y =20;
	 m->positionminijoueur.x =0;
	 m->positionminijoueur.y =0;
	 /*Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS,1024);
	 Mix_Music *music;
	 music=Mix_LoadMUS("music.mp3");
	 Mix_PlayMusic(music,-1);*/
	}
 void init_map3 (minimap *m)
	{
         
         m->map = IMG_Load("lvl33.png");
	 //m->masque= IMG_Load("obstacle.png");
	 m->minijoueur = IMG_Load("miniperso.png");
	 m->positionmap.x =230;
	 m->positionmap.y =20;
	 m->positionminijoueur.x =0;
	 m->positionminijoueur.y =0;
	 /*Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS,1024);
	 Mix_Music *music;
	 music=Mix_LoadMUS("music.mp3");
	 Mix_PlayMusic(music,-1);*/
	}
        
	
	void MAJMinimap(SDL_Rect posJoueur, minimap * m, SDL_Rect camera, float redimensionnement)
	{
	 SDL_Rect posJoueurABS;
	 posJoueurABS.x = 0;
	 posJoueurABS.y = 0;
	 posJoueurABS.x = posJoueur.x + camera.x;
	 posJoueurABS.y = posJoueur.y + camera.y;
	 m->positionminijoueur.x=(posJoueurABS.x * redimensionnement/100)+230;
	 m->positionminijoueur.y=(posJoueurABS.y * redimensionnement/100)-150;
	}

	void MAJMinimap2(SDL_Rect posJoueur, minimap * m, SDL_Rect camera, float redimensionnement)
	{
	 SDL_Rect posJoueurABS;
	 posJoueurABS.x = 0;
	 posJoueurABS.y = 0;
	 posJoueurABS.x = posJoueur.x + camera.x;
	 posJoueurABS.y = posJoueur.y + camera.y;
	 m->positionminijoueur.x=(posJoueurABS.x * redimensionnement/100)+230;
	 m->positionminijoueur.y=(posJoueurABS.y * redimensionnement/100)-307;
	}
	void afficherminimap (minimap m, SDL_Surface * screen)
	{
	 SDL_BlitSurface(m.map,NULL,screen,&m.positionmap);
	 SDL_BlitSurface(m.minijoueur,NULL,screen,&m.positionminijoueur);
	}

	
	
		//***PARTIE TEMPS***//
		

	
	void initialiser_temps(temps *t)
	{
	 t->texte = NULL; //surface qui sert à l'affichage du temps
	 t->position.x=20;
	 t->position.y=100;
	 t->police = NULL;
	 t->police = TTF_OpenFont("police.ttf", 25);
	 strcpy( t->entree,"");
	 (t->secondesEcoulees)=0;
	 time(&(t->t1));
	}
	

	
	void afficher_temps(temps *t,SDL_Surface *ecran)
	{
	 SDL_Color couleurn= {255, 255, 255};//blanc
	 time(&(t->t2));// temps actuel
	 t->secondesEcoulees = t->t2 - t->t1;
	 t->min=((t->secondesEcoulees/60)%60);
	 t->sec= ((t->secondesEcoulees)%60);
	 sprintf(t->entree,"%02d : %02d",t->min,t->sec);
	 t->texte = TTF_RenderUTF8_Solid(t->police, t->entree, couleurn);
	 SDL_BlitSurface(t->texte, NULL, ecran, &(t->position)); /* Blit du texte */
	}
		
		//Partie Perso//
/*void initPerso(Personne *p){

    
    
    p->position.x=0;
    p->position.y=530;
    p->position.w=20;
    p->position.h=10;

    

    p->images=IMG_Load("perso.png");
	if(p->images==NULL)
	exit(1);
}

void afficherPerso(Personne p, SDL_Surface * screen)
{
	SDL_Rect dsrect = {.x =  p.position.x, .y = p.position.y, .h=p.images->h, .w=p.images->w};
	SDL_BlitSurface(p.images, NULL, screen, &dsrect);
    //SDL_BlitSurface(p.images,NULL,screen,&p.position);
}


void libererperso(Personne p)
{
   SDL_FreeSurface(p.images);
}


	
		//Partie Back//
void init_background(Background *b, SDL_Surface *screen)
{
    b->img = IMG_Load("LVL1.png");
    //b->images[0] = IMG_Load("background_ani3.png");
    //b->images[1] = IMG_Load("background_ani1.png");
    //b->images[2] = IMG_Load("background_ani2.png");
    b->offset_x = 0;
    b->offset_y = b->img->h - screen->h;
    b->offset_val = OFFSET_VAL;

    b->srect.x = 0;
    b->srect.y = 0;
    b->srect.w = screen->w;
    b->srect.h = screen->h;

    b->dsrect.x = 0;
    b->dsrect.y = 0;
    b->dsrect.w = b->img->w;
    b->dsrect.h = b->img->h;
    /*b->pause=IMG_Load("pause_button.png");
    b->pause_pos.x=650;
    b->pause_pos.y=0;
    b->pause_pos.w=138;
    b->pause_pos.h=138;

    b->menu_pause = IMG_Load("menu_pause.png");
    b->menu_pos.x=250;
    b->menu_pos.y=80;
    b->menu_pos.w=590;
    b->menu_pos.h=659;

    b->score=IMG_Load("score_board.png");
    b->score_pos.x=50;
    b->score_pos.y=0;
    b->score_pos.w=590;
    b->score_pos.h=659;
}


void draw_background(Background *b, SDL_Surface *screen) 
{
    /*b->srect.x = b->offset_x % b->img->w;
    b->srect.y = b->offset_y % b->img->h;

    SDL_BlitSurface(b->img, &b->srect, screen, &b->dsrect);
    
    //SDL_BlitSurface(b->pause, NULL,screen,&b->pause_pos);
   
  //SDL_BlitSurface(tli->images[tli->current_image], NULL, screen, &tli->position);

}
void libererback(Background b)
{
	SDL_FreeSurface(b.img);
}*/
