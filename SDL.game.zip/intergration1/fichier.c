#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include "fichier.h"
#include "sauvgarder.h"
#include "lvl_1.h"
#include "lvl_2.h"

//____________________________________________ menu__________________________
int menu(int volume,SDL_Surface *screen,int m)
{

image IMAGE[3],IMAGE_BTN1[2],IMAGE_BTN2[2],IMAGE_BTN3[2],IMAGE_BTN4[2];
int select=0;
Mix_Chunk *mus;
texte txte;
SDL_Event event;
int A=0,B=0,C=0,D=0,i=0,on_play=0;
int boucle =1,choix=0;
//bouton menu
int bg=0,b1,b2,b3;
IMAGE[0].img=SDL_LoadBMP("Baground1.bmp");
IMAGE[1].img=SDL_LoadBMP("Baground1 (copie).bmp");
IMAGE[2].img=SDL_LoadBMP("baground2.bmp");

IMAGE_BTN1[0].img=IMG_Load("play.png");
IMAGE_BTN1[1].img=IMG_Load("play2.png");

IMAGE_BTN2[0].img=IMG_Load("quit.png");
IMAGE_BTN2[1].img=IMG_Load("quit2.png");

IMAGE_BTN3[0].img=IMG_Load("option.png");
IMAGE_BTN3[1].img=IMG_Load("option2.png");

IMAGE_BTN4[0].img=IMG_Load("load1.png");
IMAGE_BTN4[1].img=IMG_Load("load.png");
//bouton option




//initialisation
if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO|SDL_INIT_TIMER)==-1)
{
printf("could not initialize SDL: %s.\n",SDL_GetError());

}
screen=SDL_SetVideoMode(SCREEN_W,SCREEN_H,32,SDL_SWSURFACE|SDL_DOUBLEBUF);
initialiser_imageBACK(&IMAGE[0]);
initialiser_imageBACK(&IMAGE[1]);
initialiser_imageBACK(&IMAGE[2]);
initialiser_imageBOUTON1(&IMAGE_BTN1[0]);
initialiser_imageBOUTON1(&IMAGE_BTN1[1]);
initialiser_imageBOUTON2(&IMAGE_BTN2[0]);
initialiser_imageBOUTON2(&IMAGE_BTN2[1]);
initialiser_imageBOUTON3(&IMAGE_BTN3[0]);
initialiser_imageBOUTON3(&IMAGE_BTN3[1]);
initialiser_imageBOUTON4(&IMAGE_BTN4[0]);
initialiser_imageBOUTON4(&IMAGE_BTN4[1]);
Mix_VolumeMusic(volume);
initialiser_texte(&txte);


//boucle du jeu
while(boucle)
{
i=0;
afficher_imageBMP(screen,IMAGE[bg]);
if(A==0)
	afficher_imageBTN1(screen,IMAGE_BTN1[0]);
else
	afficher_imageBTN1(screen,IMAGE_BTN1[1]);

if(B==0)
	afficher_imageBTN2(screen,IMAGE_BTN2[0]);
else
	afficher_imageBTN2(screen,IMAGE_BTN2[1]);
if(C==0)
	afficher_imageBTN3(screen,IMAGE_BTN3[0]);
else
	afficher_imageBTN3(screen,IMAGE_BTN3[1]);
if(D==0)
	afficher_imageBTN4(screen,IMAGE_BTN4[0]);
else
	afficher_imageBTN4(screen,IMAGE_BTN4[1]);

afficher_texte(screen,txte);
while(SDL_PollEvent(&event))
{
switch(event.type)
{
case SDL_QUIT:
boucle=0;
break;
case SDL_MOUSEBUTTONDOWN:
if(event.button.button==SDL_BUTTON_LEFT)
{
int x=event.button.x;
int y=event.button.y;
if (is_button_clicked(x, y,284,140,110,55)==1) 
{
	

 initialiser_audiobref(mus);
SDL_Delay(500);
	 play_level1();

}

if (is_button_clicked(x, y,284,210,110,55)==1) 
{
 initialiser_audiobref(mus);
SDL_Delay(500);
    choix=on_option_button_click(&volume,screen,&m);//if choix ==1 sauvgarder
    if(choix==1)
	return 1;
}

if (is_button_clicked(x, y,284,280,110,55)==1) 
{
 initialiser_audiobref(mus);
SDL_Delay(500);
    SDL_Quit();
    exit(0); 
}

if (is_button_clicked(x, y,284,350,110,55)==1) //load
{
 initialiser_audiobref(mus);
SDL_Delay(500);
    return 2;//load

}


}
break;
case SDL_MOUSEMOTION:

if(event.motion.x >= 284 && event.motion.x <=284 + 110 && event.motion.y >=140 && event.motion.y <= 140 + 58) 
{


// La souris est sur le bouton

A=1;



}
else 
{

// La souris n'est pas sur le bouton

A=0;

}


if(event.motion.x >= 284 && event.motion.x <=284 + 110 && event.motion.y >=280 && event.motion.y <= 280 + 55) 
{

B=1;

}
else 
{

B=0;
}


if(event.motion.x >= 284 && event.motion.x <=284 + 110 && event.motion.y >=210 && event.motion.y <= 210 + 55) 
{


C=1;

}
else 
{

C=0;
}

if(event.motion.x >= 284 && event.motion.x <=284 + 110 && event.motion.y >=350 && event.motion.y <= 350 + 55) 
{


D=1;

}
else 
{

D=0;
}

break;

case SDL_KEYDOWN:
	switch(event.key.keysym.sym)
	{
	case SDLK_ESCAPE:
	SDL_Quit();
    	exit(0);
	break;
	case SDLK_p:
	play_level1();
	
	break;
	case SDLK_r:
	play_level2();
	
	break;
	case SDLK_o:
	on_option_button_click(&volume,screen,&m);
	break;
	case SDLK_DOWN:
	if(select==0)
	{
	A=1;
	select++;
	}
	else if(select==1)
	{
	B=1;
	select++;
	}
	else if(select==2)
	{
	C=1;
	select=0;
	}
	break;
	default:{};
}
}
}

if(bg==3)
bg=0;
else
bg++;
SDL_Flip(screen);
}//fin de la boucle

//liberation
liberer_image(IMAGE[0]);
liberer_image(IMAGE[1]);
liberer_image(IMAGE[2]);
liberer_image(IMAGE_BTN1[0]);
liberer_image(IMAGE_BTN1[1]);
liberer_image(IMAGE_BTN2[0]);
liberer_image(IMAGE_BTN2[1]);
liberer_image(IMAGE_BTN3[0]);
liberer_image(IMAGE_BTN3[1]);
liberer_image(IMAGE_BTN4[0]);
liberer_image(IMAGE_BTN4[1]);



liberer_musiquebref(mus);

liberer_texte(txte);

return 0;
}

//_______________________________________menu___________________________________________


void initialiser_imageBACK(image *imge)
{
if(imge->img==NULL)
{
printf("unable to load backgroud image %s \n",SDL_GetError());
return;
}
imge->pos_img_ecran.x=0;
imge->pos_img_ecran.y=0;
imge->pos_img_affiche.x=0;
imge->pos_img_affiche.y=0;
imge->pos_img_affiche.h=SCREEN_H;
imge->pos_img_affiche.w=SCREEN_W;
}

void initialiser_imageBOUTON1(image *imgbtn)
{

if(imgbtn->img==NULL)
{
printf("unable to load backgroud image %s \n",SDL_GetError());
return;
}
imgbtn->pos_img_ecran.x=284;
imgbtn->pos_img_ecran.y=140;
imgbtn->pos_img_affiche.w=237;
imgbtn->pos_img_affiche.h=58;
imgbtn->pos_img_affiche.x=((SCREEN_W-imgbtn->pos_img_affiche.w)/2);
imgbtn->pos_img_affiche.y=((SCREEN_H-imgbtn->pos_img_affiche.h)/3);
}

void initialiser_imageBOUTON2(image *imgbtn)
{

if(imgbtn->img==NULL)
{
printf("unable to load backgroud image %s \n",SDL_GetError());
return;
}
imgbtn->pos_img_ecran.x=284;
imgbtn->pos_img_ecran.y=280;
imgbtn->pos_img_affiche.w=236;
imgbtn->pos_img_affiche.h=55;
imgbtn->pos_img_affiche.x=((SCREEN_W-imgbtn->pos_img_affiche.w)/2);
imgbtn->pos_img_affiche.y=(2*(SCREEN_H-imgbtn->pos_img_affiche.h)/3);
}

void initialiser_imageBOUTON3(image *imgbtn)
{

if(imgbtn->img==NULL)
{
printf("unable to load backgroud image %s \n",SDL_GetError());
return;
}
imgbtn->pos_img_ecran.x=284;
imgbtn->pos_img_ecran.y=210;
imgbtn->pos_img_affiche.w=236;
imgbtn->pos_img_affiche.h=55;
imgbtn->pos_img_affiche.x=((SCREEN_W-imgbtn->pos_img_affiche.w)/2);
imgbtn->pos_img_affiche.y=((SCREEN_H-imgbtn->pos_img_affiche.h));
}


void initialiser_imageBOUTON4(image *imgbtn)
{

if(imgbtn->img==NULL)
{
printf("unable to load backgroud image %s \n",SDL_GetError());
return;
}
imgbtn->pos_img_ecran.x=284;
imgbtn->pos_img_ecran.y=350;
imgbtn->pos_img_affiche.w=237;
imgbtn->pos_img_affiche.h=58;
imgbtn->pos_img_affiche.x=((SCREEN_W-imgbtn->pos_img_affiche.w)/2);
imgbtn->pos_img_affiche.y=((SCREEN_H-imgbtn->pos_img_affiche.h)/3);
}


void afficher_imageBMP(SDL_Surface *screen,image imge)
{
SDL_BlitSurface(imge.img,&imge.pos_img_affiche,screen,&imge.pos_img_ecran);
}

void afficher_imageBTN1(SDL_Surface *screen,image imge)
{
SDL_BlitSurface(imge.img,NULL,screen,&imge.pos_img_ecran);
}

void afficher_imageBTN2(SDL_Surface *screen,image imge)
{
SDL_BlitSurface(imge.img,NULL,screen,&imge.pos_img_ecran);
}

void afficher_imageBTN3(SDL_Surface *screen,image imge)
{
SDL_BlitSurface(imge.img,NULL,screen,&imge.pos_img_ecran);
}

void afficher_imageBTN4(SDL_Surface *screen,image imge)
{
SDL_BlitSurface(imge.img,NULL,screen,&imge.pos_img_ecran);
}

void liberer_image(image imge)
{
SDL_FreeSurface(imge.img);
}
//volume 
int initialiser_audio(Mix_Music *music)
{
int volume;
if(Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,2048)==-1)
{
printf("%s",SDL_GetError());
}
music=Mix_LoadMUS("u.mp3");
Mix_PlayMusic(music,-1);
volume=60;
//volume=MIX_MAX_VOLUME;
Mix_VolumeMusic(volume);
//printf("volume=%d|||||",volume);
return volume;
}

void liberer_musique(Mix_Music *music)
{
Mix_FreeMusic(music);
}

void initialiser_audiobref(Mix_Chunk *music)
{
Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,2,1024);
music=Mix_LoadWAV("sons.wav");
Mix_PlayChannel(-1,music,0);
if(music==NULL)printf("%s",SDL_GetError());
}

void liberer_musiquebref(Mix_Chunk *music)
{
Mix_FreeChunk(music);
}

void initialiser_texte(texte *txte)
{
TTF_Init();
txte->police=TTF_OpenFont("text.ttf",35);
txte->color_txt.r=80;
txte->color_txt.g=0;
txte->color_txt.b=0;

txte->pos_txt.x=148;
txte->pos_txt.y=20;
}

void afficher_texte(SDL_Surface *screen,texte txte)
{
txte.txt=TTF_RenderText_Blended(txte.police,"the killer birthday party",txte.color_txt);
SDL_BlitSurface(txte.txt,NULL,screen,&txte.pos_txt);
}

void liberer_texte(texte txte)
{
TTF_CloseFont(txte.police);
TTF_Quit();
}
//------------------------------------------play------------------------------------------
void on_play_button_click() 
{
    image IMAGE;
    SDL_Surface *game_screen = SDL_SetVideoMode(SCREEN_W,SCREEN_H, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
    initialiser_imageBACK_jeu(&IMAGE);
    SDL_WM_SetCaption("Mon jeu", NULL);
    // Chargez les ressources nécessaires pour votre jeu
    // Affichez le contenu de votre jeu sur la nouvelle fenêtre
    while (1) {
        // Boucle de jeu
        // Attendez que l'utilisateur ferme la fenêtre
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
	    afficher_image_jeu(game_screen,IMAGE);
            if (event.type == SDL_QUIT) {
                SDL_Quit();
                exit(0);
            }
	SDL_Flip(game_screen);

        }
    }
liberer_image(IMAGE);
}

int is_button_clicked(int x, int y, int x_rect, int y_rect, int w_rect, int h_rect) {
    if (x >= x_rect && x <= x_rect + w_rect &&
        y >= y_rect && y <= y_rect + h_rect) {
        return 1;
    } else {
        return -1;
    }
}

void initialiser_imageBACK_jeu(image *imge)
{
imge->url="45.bmp";
imge->img=SDL_LoadBMP(imge->url);
if(imge->img==NULL)
{
printf("unable to load backgroud image %s \n",SDL_GetError());
return;
}
imge->pos_img_ecran.x=0;
imge->pos_img_ecran.y=0;
imge->pos_img_affiche.x=0;
imge->pos_img_affiche.y=0;
imge->pos_img_affiche.h=SCREEN_H;
imge->pos_img_affiche.w=SCREEN_W;
}

void afficher_image_jeu(SDL_Surface *screen,image imge)
{
SDL_BlitSurface(imge.img,&imge.pos_img_affiche,screen,&imge.pos_img_ecran);
}
//---------------------------------options--------------------------------------------------------------------
int on_option_button_click(int *volume,SDL_Surface *screen,int *m)
{
    int f=1,tmp,A=0,B=0,C=0,D=0,E=0,F=0;
    texte txte_s,texte_pe,texte_m,texte_ops;
    image IMAGE,IMAGE_PE[2],IMAGE_PLUS[2],IMAGE_MOIN[2],IMAGE_MUTE[2],IMAGE_RETURN[2],IMAGE_SAUVGARDER[2],IMAGE_barre[6];
    SDL_Surface *option_screen = SDL_SetVideoMode(1000,500, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
    initialiser_imageBACK_option(&IMAGE);
    IMAGE_PE[0].img=IMG_Load("pe.png");
    IMAGE_PE[1].img=IMG_Load("pe1.png");
    IMAGE_PLUS[0].img=IMG_Load("plus.png");
    IMAGE_PLUS[1].img=IMG_Load("plus1.png");
    IMAGE_MOIN[0].img=IMG_Load("moin.png");
    IMAGE_MOIN[1].img=IMG_Load("moin1.png");
    IMAGE_MUTE[0].img=IMG_Load("mute.png");
    IMAGE_MUTE[1].img=IMG_Load("mute1.png");
    IMAGE_RETURN[0].img=IMG_Load("return.png");
    IMAGE_RETURN[1].img=IMG_Load("return1.png");
    IMAGE_SAUVGARDER[0].img=IMG_Load("sauvgarder.png");
    IMAGE_SAUVGARDER[1].img=IMG_Load("sauvgarder1.png");
    IMAGE_barre[0].img=IMG_Load("barre0.png");	
    IMAGE_barre[1].img=IMG_Load("barre1.png");
    IMAGE_barre[2].img=IMG_Load("barre2.png");
    IMAGE_barre[3].img=IMG_Load("barre3.png");
    IMAGE_barre[4].img=IMG_Load("barre4.png");
    IMAGE_barre[5].img=IMG_Load("barre5.png");
		


    initialiser_imageBOUTON_plain_ecran(&IMAGE_PE[0]);
    initialiser_imageBOUTON_plain_ecran(&IMAGE_PE[1]);
    initialiser_imageBOUTON_plus(&IMAGE_PLUS[0]);
    initialiser_imageBOUTON_plus(&IMAGE_PLUS[1]);
    initialiser_imageBOUTON_moin(&IMAGE_MOIN[0]);
    initialiser_imageBOUTON_moin(&IMAGE_MOIN[1]);
    initialiser_texte_option_sons(&txte_s);
    initialiser_texte_option_pe(&texte_pe);
    initialiser_imageBOUTON_mute(&IMAGE_MUTE[0]);
    initialiser_imageBOUTON_mute(&IMAGE_MUTE[1]);
    initialiser_texte_option_mute(&texte_m);
    initialiser_texte_option_option(&texte_ops);
    initialiser_imageBOUTON_return(&IMAGE_RETURN[0]);
    initialiser_imageBOUTON_return(&IMAGE_RETURN[1]);
    initialiser_imagesauvgarder(&IMAGE_SAUVGARDER[0]);
    initialiser_imagesauvgarder(&IMAGE_SAUVGARDER[1]);
    initialiser_images_barre_sons(&IMAGE_barre[0]);
		initialiser_images_barre_sons(&IMAGE_barre[1]);
		initialiser_images_barre_sons(&IMAGE_barre[2]);
		initialiser_images_barre_sons(&IMAGE_barre[3]);
		initialiser_images_barre_sons(&IMAGE_barre[4]);
		initialiser_images_barre_sons(&IMAGE_barre[5]);




    SDL_WM_SetCaption("option", NULL);
    // Chargez les ressources nécessaires pour option
    
    // Affichez le contenu de votre jeu sur la nouvelle fenêtre
    while (1) 
{
        afficher_image_option(option_screen,IMAGE);
	if(A==0)
		afficher_imageBOUTON_option(option_screen,IMAGE_PE[0]);
	else
		afficher_imageBOUTON_option(option_screen,IMAGE_PE[1]);
	if(B==0)
		afficher_imageBOUTON_option(option_screen,IMAGE_PLUS[0]);
	else
		afficher_imageBOUTON_option(option_screen,IMAGE_PLUS[1]);
	if(C==0)
		afficher_imageBOUTON_option(option_screen,IMAGE_MOIN[0]);
	else
		afficher_imageBOUTON_option(option_screen,IMAGE_MOIN[1]);
	if(D==0)
		afficher_imageBOUTON_option(option_screen,IMAGE_MUTE[0]);
	else
		afficher_imageBOUTON_option(option_screen,IMAGE_MUTE[1]);
	if(E==0)
		afficher_imageBOUTON_option(option_screen,IMAGE_RETURN[0]);
	else
		afficher_imageBOUTON_option(option_screen,IMAGE_RETURN[1]);
	if(F==0)
		afficher_imageBOUTON_option(option_screen,IMAGE_SAUVGARDER[0]);
	else
		afficher_imageBOUTON_option(option_screen,IMAGE_SAUVGARDER[1]);
if((*volume)==0)
		afficher_imageBOUTON_option(option_screen,IMAGE_barre[0]);
else if((*volume)==20)
		afficher_imageBOUTON_option(option_screen,IMAGE_barre[1]);
else if((*volume)==40)
		afficher_imageBOUTON_option(option_screen,IMAGE_barre[2]);
else if((*volume)==60)
		afficher_imageBOUTON_option(option_screen,IMAGE_barre[3]);
else if((*volume)==80)
		afficher_imageBOUTON_option(option_screen,IMAGE_barre[4]);
else if((*volume)==100)
		afficher_imageBOUTON_option(option_screen,IMAGE_barre[5]);




	afficher_texte_option_sons(option_screen,txte_s);
        afficher_texte_option_pe(option_screen,texte_pe);
	afficher_texte_option_mute(option_screen,texte_m);
        afficher_texte_option_option(option_screen,texte_ops);
       
        SDL_Event event;
        while (SDL_PollEvent(&event)) 
 {

	    switch(event.type)
  {
		case SDL_QUIT:
		SDL_Quit();
		exit(0);
		break;
		case SDL_MOUSEMOTION:

		if(event.motion.x >= 360 && event.motion.x <=360 + 70 && event.motion.y >=280 && event.motion.y <= 280 + 58) 
		{


		// La souris est sur le bouton

		A=1;



		}
		else 
		{

		// La souris n'est pas sur le bouton

		A=0;

		}


		if(event.motion.x >= 230 && event.motion.x <=230 + 70 && event.motion.y >=80 && event.motion.y <= 80 + 58) 
		{

		B=1;

		}
		else 
		{

		B=0;
		}


		if(event.motion.x >= 430 && event.motion.x <=430 + 70 && event.motion.y >=80 && event.motion.y <= 80 + 58) 
		{


		C=1;

		}
		else 
		{

		C=0;
		}

		if(event.motion.x >=360 && event.motion.x <=360 + 70 && event.motion.y >=180 && event.motion.y <=180 + 58) 
		{


		D=1;

		}
		else 
		{

		D=0;
		}
		if(event.motion.x >= 550 && event.motion.x <=550 + 70 && event.motion.y >=330 && event.motion.y <= 330 + 58) 
		{


		E=1;

		}
		else 
		{

		E=0;
		}
		if(event.motion.x >= 250 && event.motion.x <=250 + 100 && event.motion.y >=350 && event.motion.y <= 350 + 55) 
		{


		F=1;

		}
		else 
		{

		F=0;
		}




		break;






		case SDL_MOUSEBUTTONDOWN:
		if(event.button.button==SDL_BUTTON_LEFT)
	{
		int x=event.button.x;
		int y=event.button.y;

		if(is_button_clicked(x,y,230,80,50,58)==1)
                {
		(*volume)+=20;
		if((*volume)>100)
		  (*volume)=100;
		printf("%d|",*volume);
		Mix_VolumeMusic(*volume);
                }
		else if(is_button_clicked(x,y,430,80,50,58)==1)
                {
		(*volume)-=20;
		if((*volume)<0)
		  (*volume)=0;
		printf("%d|",*volume);
      		Mix_VolumeMusic(*volume);
                }

		else if(is_button_clicked(x,y,360,270,50, 58)==1)
                {
		if(f==0)
		 {
		screen = SDL_SetVideoMode(640,410, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
                f = 1;
		 }
		else
		 {
		screen = SDL_SetVideoMode(610,380, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
                f = 0;

		 }	

                }
		else if(is_button_clicked(x,y,360,180,50, 58)==1)
		{
		if((*m)==0)
		{
		tmp=(*volume);
		(*volume)=0;
		(*m)=1;
		Mix_VolumeMusic(*volume);
		}
		else if((*m)==1)
		{
		(*volume)=tmp;
		(*m)=0;
		Mix_VolumeMusic(*volume);
		}
		
		
		}
		else if(is_button_clicked(x,y,550,330,50, 58)==1)
		{
		menu(*volume,screen,*m);
		}
		else if(is_button_clicked(x,y,250,350,100, 55)==1)
		{
		return 1 ;
		}
		

	}
		break;
	//printf("first %d |",*volume);	
	case SDL_KEYDOWN:
	switch(event.key.keysym.sym)
	{
	case SDLK_ESCAPE:
	SDL_Quit();
    	exit(0);
	break;
	case SDLK_UP:
	(*volume)+=20;
	if((*volume)>100)
	  (*volume)=100;
	Mix_VolumeMusic(*volume);
printf("%d|",*volume);
	break;
	
	case SDLK_DOWN:
	(*volume)-=20;
	if((*volume)<0)
	  (*volume)=0;
	Mix_VolumeMusic(*volume);
printf("%d|",*volume);
	break;
	case SDLK_r:
	menu(*volume,screen,*m);
	break;
	
	default:{};
}

break;

   }
	    
         
	SDL_Flip(option_screen);

  }
 }



liberer_image(IMAGE_PE[0]);
liberer_image(IMAGE_PE[1]);
liberer_image(IMAGE_PLUS[0]);
liberer_image(IMAGE_PLUS[1]);
liberer_image(IMAGE_MOIN[0]);
liberer_image(IMAGE_MOIN[1]);
liberer_image(IMAGE_MUTE[0]);
liberer_image(IMAGE_MUTE[1]);
liberer_image(IMAGE_RETURN[0]);
liberer_image(IMAGE_RETURN[1]);
liberer_image(IMAGE_barre[0]);
liberer_image(IMAGE_barre[1]);
liberer_image(IMAGE_barre[2]);
liberer_image(IMAGE_barre[3]);
liberer_image(IMAGE_barre[4]);
liberer_image(IMAGE_barre[5]);
liberer_image(IMAGE);
liberer_image(IMAGE_SAUVGARDER[0]);
liberer_image(IMAGE_SAUVGARDER[1]);
liberer_texte(txte_s);
liberer_texte(texte_pe);
liberer_texte(texte_m);
liberer_texte(texte_ops);


return 0;
}


void afficher_image_option(SDL_Surface *screen,image imge)
{
SDL_BlitSurface(imge.img,&imge.pos_img_affiche,screen,&imge.pos_img_ecran);
}

void initialiser_imageBACK_option(image *imge)
{
imge->url="op.bmp";
imge->img=SDL_LoadBMP(imge->url);
if(imge->img==NULL)
{
printf("unable to load backgroud image %s \n",SDL_GetError());
return;
}
imge->pos_img_ecran.x=0;
imge->pos_img_ecran.y=0;
imge->pos_img_affiche.x=0;
imge->pos_img_affiche.y=0;
imge->pos_img_affiche.h=600;
imge->pos_img_affiche.w=1000;
}

//fenetre d'option
//bouton (+)
void initialiser_imageBOUTON_plus(image *imgbtn)
{

if(imgbtn->img==NULL)
{
printf("unable to load backgroud image %s \n",SDL_GetError());
return;
}
imgbtn->pos_img_ecran.x=230;
imgbtn->pos_img_ecran.y=80;
imgbtn->pos_img_affiche.w=70;
imgbtn->pos_img_affiche.h=58;
imgbtn->pos_img_affiche.x=((SCREEN_W-imgbtn->pos_img_affiche.w)/2);
imgbtn->pos_img_affiche.y=((SCREEN_H-imgbtn->pos_img_affiche.h)/3);
}

//bouton (-)
void initialiser_imageBOUTON_moin(image *imgbtn)
{

if(imgbtn->img==NULL)
{
printf("unable to load backgroud image %s \n",SDL_GetError());
return;
}
imgbtn->pos_img_ecran.x=430;
imgbtn->pos_img_ecran.y=80;
imgbtn->pos_img_affiche.w=70;
imgbtn->pos_img_affiche.h=58;
imgbtn->pos_img_affiche.x=((SCREEN_W-imgbtn->pos_img_affiche.w)/2);
imgbtn->pos_img_affiche.y=((SCREEN_H-imgbtn->pos_img_affiche.h)/3);
}
//bouton plain ecran
void initialiser_imageBOUTON_plain_ecran(image *imgbtn)
{

if(imgbtn->img==NULL)
{
printf("unable to load backgroud image %s \n",SDL_GetError());
return;
}
imgbtn->pos_img_ecran.x=360;
imgbtn->pos_img_ecran.y=280;
imgbtn->pos_img_affiche.w=70;
imgbtn->pos_img_affiche.h=58;
imgbtn->pos_img_affiche.x=((SCREEN_W-imgbtn->pos_img_affiche.w)/2);
imgbtn->pos_img_affiche.y=((SCREEN_H-imgbtn->pos_img_affiche.h)/3);
}

//bouton mute
void initialiser_imageBOUTON_mute(image *imgbtn)
{

if(imgbtn->img==NULL)
{
printf("unable to load backgroud image %s \n",SDL_GetError());
return;
}
imgbtn->pos_img_ecran.x=360;
imgbtn->pos_img_ecran.y=180;
imgbtn->pos_img_affiche.w=70;
imgbtn->pos_img_affiche.h=58;
imgbtn->pos_img_affiche.x=((SCREEN_W-imgbtn->pos_img_affiche.w)/2);
imgbtn->pos_img_affiche.y=((SCREEN_H-imgbtn->pos_img_affiche.h)/3);
}



//affichage

void afficher_imageBOUTON_option(SDL_Surface *screen,image imge)
{
SDL_BlitSurface(imge.img,NULL,screen,&imge.pos_img_ecran);
}

void initialiser_texte_option_sons(texte *txte)
{
TTF_Init();
txte->police=TTF_OpenFont("option.ttf",25);
txte->color_txt.r=255;
txte->color_txt.g=255;
txte->color_txt.b=255;

txte->pos_txt.x=75;
txte->pos_txt.y=100;

}

void initialiser_texte_option_pe(texte *txte)
{
TTF_Init();
txte->police=TTF_OpenFont("option.ttf",25);
txte->color_txt.r=255;
txte->color_txt.g=255;
txte->color_txt.b=255;

txte->pos_txt.x=75;
txte->pos_txt.y=300;

}

void initialiser_texte_option_mute(texte *txte)
{
TTF_Init();
txte->police=TTF_OpenFont("option.ttf",25);
txte->color_txt.r=255;
txte->color_txt.g=255;
txte->color_txt.b=255;

txte->pos_txt.x=75;
txte->pos_txt.y=200;

}

void initialiser_texte_option_option(texte *txte)
{
TTF_Init();
txte->police=TTF_OpenFont("option.ttf",35);
txte->color_txt.r=200;
txte->color_txt.g=0;
txte->color_txt.b=0;

txte->pos_txt.x=220;
txte->pos_txt.y=20;

}

void afficher_texte_option_mute(SDL_Surface *screen,texte txte)
{
txte.txt=TTF_RenderText_Blended(txte.police,"mute ",txte.color_txt);
SDL_BlitSurface(txte.txt,NULL,screen,&txte.pos_txt);
}



void afficher_texte_option_option(SDL_Surface *screen,texte txte)
{
txte.txt=TTF_RenderText_Blended(txte.police,"options ",txte.color_txt);
SDL_BlitSurface(txte.txt,NULL,screen,&txte.pos_txt);
}


void afficher_texte_option_sons(SDL_Surface *screen,texte txte)
{
txte.txt=TTF_RenderText_Blended(txte.police,"sound ",txte.color_txt);
SDL_BlitSurface(txte.txt,NULL,screen,&txte.pos_txt);
}

void afficher_texte_option_pe(SDL_Surface *screen,texte txte)
{
txte.txt=TTF_RenderText_Blended(txte.police,"full screen ",txte.color_txt);
SDL_BlitSurface(txte.txt,NULL,screen,&txte.pos_txt);
}


//return menu

void initialiser_imageBOUTON_return(image *imgbtn)
{

if(imgbtn->img==NULL)
{
printf("unable to load backgroud image %s \n",SDL_GetError());
return;
}
imgbtn->pos_img_ecran.x=550;
imgbtn->pos_img_ecran.y=330;
imgbtn->pos_img_affiche.w=70;
imgbtn->pos_img_affiche.h=58;
imgbtn->pos_img_affiche.x=((SCREEN_W-imgbtn->pos_img_affiche.w)/2);
imgbtn->pos_img_affiche.y=((SCREEN_H-imgbtn->pos_img_affiche.h)/3);
}

////fichier.h  
void initialiser_imagesauvgarder(image *imgbtn)
{

if(imgbtn->img==NULL)
{
printf("unable to load backgroud image %s \n",SDL_GetError());
return;
}
imgbtn->pos_img_ecran.x=250;
imgbtn->pos_img_ecran.y=350;
imgbtn->pos_img_affiche.w=100;
imgbtn->pos_img_affiche.h=55;
imgbtn->pos_img_affiche.x=((SCREEN_W-imgbtn->pos_img_affiche.w)/2);
imgbtn->pos_img_affiche.y=((SCREEN_H-imgbtn->pos_img_affiche.h));
}

void initialiser_images_barre_sons(image *imgbtn)
{

if(imgbtn->img==NULL)
{
printf("unable to load backgroud image %s \n",SDL_GetError());
return;
}
imgbtn->pos_img_ecran.x=310;
imgbtn->pos_img_ecran.y=80;
imgbtn->pos_img_affiche.w=100;
imgbtn->pos_img_affiche.h=55;
imgbtn->pos_img_affiche.x=((SCREEN_W-imgbtn->pos_img_affiche.w)/2);
imgbtn->pos_img_affiche.y=((SCREEN_H-imgbtn->pos_img_affiche.h));
}


