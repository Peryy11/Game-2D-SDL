#ifndef FUNCTION_H
#define FUNCTION_H
#include<SDL/SDL.h>
#include<SDL/SDL_image.h>
#include<SDL/SDL_mixer.h>
#include<SDL/SDL_ttf.h>
#define SCREEN_H 410
#define SCREEN_W 640

typedef struct
{
	char *url;
	SDL_Rect pos_img_affiche;
	SDL_Rect pos_img_ecran;
	SDL_Surface *img;
}image;

typedef struct
{
	SDL_Surface *txt;
	SDL_Rect pos_txt;
	SDL_Colour color_txt;
	TTF_Font *police;
}texte;

int menu(int volume,SDL_Surface *screen,int m);

void initialiser_imageBACK(image *imge);
void initialiser_imageBOUTON1(image *imgbtn);
void initialiser_imageBOUTON2(image *imgbtn);
void initialiser_imageBOUTON3(image *imgbtn);
void initialiser_imageBOUTON4(image *imgbtn);
void initialiser_imageBACK_jeu(image *imge);
void initialiser_imageBACK_option(image *imge);
void initialiser_imageBOUTON_plus(image *imgbtn);
void initialiser_imageBOUTON_moin(image *imgbtn);
void initialiser_imageBOUTON_plain_ecran(image *imgbtn);
void initialiser_texte_option_sons(texte *txte);
void initialiser_texte_option_pe(texte *txte);
void initialiser_imageBOUTON_mute(image *imgbtn);
void initialiser_texte_option_mute(texte *txte);
void initialiser_texte_option_option(texte *txte);
void initialiser_imageBOUTON_return(image *imgbtn);
void initialiser_imagesauvgarder(image *imgbtn);
void initialiser_images_barre_sons(image *imgbtn);

void afficher_imageBMP(SDL_Surface *screen,image imge);
void afficher_imageBTN1(SDL_Surface *screen,image imge);
void afficher_imageBTN2(SDL_Surface *screen,image imge);
void afficher_imageBTN3(SDL_Surface *screen,image imge);
void afficher_imageBTN4(SDL_Surface *screen,image imge);
void afficher_image_jeu(SDL_Surface *screen,image imge);
void afficher_image_option(SDL_Surface *screen,image imge);
void afficher_imageBOUTON_option(SDL_Surface *screen,image imge);
void afficher_texte_option_mute(SDL_Surface *screen,texte txte);
void afficher_texte_option_option(SDL_Surface *screen,texte txte);
void liberer_image(image imge);

int initialiser_audio(Mix_Music *music);
void liberer_musique(Mix_Music *music);

void initialiser_audiobref(Mix_Chunk *music);
void liberer_musiquebref(Mix_Chunk *music);

void initialiser_texte(texte *txte);
void afficher_texte_option_sons(SDL_Surface *screen,texte txte);
void afficher_texte_option_pe(SDL_Surface *screen,texte txte);
void afficher_texte(SDL_Surface *screen,texte txte);
void liberer_texte(texte txte);

int is_button_clicked(int x, int y, int x_rect, int y_rect, int w_rect, int h_rect);

void on_play_button_click();
int on_option_button_click(int *volume,SDL_Surface *screen,int *m);



#endif

