        #ifndef minimap_H
	#define minimap_H
	#include <stdio.h>
	#include <stdlib.h> 
	#include <SDL/SDL.h>
	#include <SDL/SDL_image.h>
	#include <SDL/SDL_mixer.h>
	#include <SDL/SDL_ttf.h>
	#include <string.h>
	#include <time.h>
	#define OFFSET_VAL 5

        
	//minimap
	typedef struct 
	{
	SDL_Surface *map;
        SDL_Surface *masque;
	SDL_Surface  *minijoueur;
	SDL_Rect positionmap;
        SDL_Rect positionmasque;
	SDL_Rect positionminijoueur;
	}minimap;
	

	//temps
	typedef struct temps
	{
	 SDL_Surface *texte;//image qui contient le temps
	 SDL_Rect position;// position du clock
	 TTF_Font *police ;
	 char entree[100]; // chaine de caractere . forme "mm:ss"
	 int secondesEcoulees; // variable entier qui contient le nbre de secondes ecoulés
	 SDL_Color couleurn;// couleur de texte a afficher
	 time_t t1,t2; //t1 temps initiale ,,, t2 temps actuel
	 int min, sec;// minutes et secondes
	}temps;
	
	//partie collision
	//sarra
	
/*typedef struct Personne
{
    SDL_Surface *images;
    SDL_Rect position;
    int direction;
    int nbr_frame;
    double vitesse,acceleration,vitesse_saut;
    float gravity;
    float velocity_y;
    int is_jumping;
    double dx;
    int ground,up,jump;

}Personne;*/


	
	//nour
	/*typedef struct {
int offset_x;
int offset_y;
int offset_val;
SDL_Surface *images; //animation
SDL_Rect srect;
SDL_Rect pause_pos;
SDL_Rect score_pos; 
SDL_Rect menu_pos;
SDL_Rect dsrect;
SDL_Surface *img,*pause,*score;
SDL_Surface *menu_pause,*win;
SDL_Surface *obstacle;
int i;
} Background;*/
	
	//fonctions:
	
	//fonction map
	void init_map (minimap *m);
void init_map2 (minimap *m);
	void MAJMinimap(SDL_Rect posJoueur,  minimap * m, SDL_Rect camera, float redimensionnement);
	void afficherminimap (minimap m, SDL_Surface * screen);
	void MAJMinimap2(SDL_Rect posJoueur, minimap * m, SDL_Rect camera, float redimensionnement);
	//fonction temps
	void initialiser_temps(temps *t);
	void afficher_temps(temps *t, SDL_Surface *ecran);
 void init_map3 (minimap *m);
        //fonction collision
	

	//fonction perso	
	/*void initPerso(Personne *p);
	void afficherPerso(Personne p, SDL_Surface * screen);
	void libererperso(Personne p);*/

	//fonction background
	/*void init_background(Background *b, SDL_Surface *screen);
	void draw_background(Background *b, SDL_Surface *screen);
	void libererback(Background b);*/
	
	#endif
