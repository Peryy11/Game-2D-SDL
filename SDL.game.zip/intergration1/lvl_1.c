#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <ctype.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <string.h>
#include <SDL/SDL_mixer.h>
#include <time.h>
#include "perso.h"
#include "function.h"
#include "es.h"
#include "enigmeimg.h"
#include "enigme.h"
#include "minimap.h"
#include "main.h"
#include "tictactoe.h"
#include "lvl_1.h"
#include "perso.h"
#include "lvl_2.h"
#include "lvl_3.h"


#define WIDTH 800
#define HEIGHT 600

int play_level1()
{
int win =false;
int scoreB =0,lvl2;
int anim=1;
minimap m;
SDL_Rect camera;
temps t;
score s;
 camera.x=0;
 camera.y=0;
camera.w=1300;
camera.h=800;
int xo=0;
 // Define the dimensions of the button and menu images
    const int BUTTON_WIDTH = 138;
    const int BUTTON_HEIGHT = 138;
    const int MENU_WIDTH = 364;
    const int MENU_HEIGHT = 503;
 const int door_width = 90;
    const int door_height = 127;
    // Load the button and menu images
    SDL_Surface* menu_image = load_image("menu_pause.png");
    SDL_Surface* button_image = load_image("pause_button.png");
    // Define the position of the button and menu
 SDL_Surface* door_image = load_image("background_win.png");
    // Define the position of the button and menu
    int button_x = 650;
    int button_y = 0;
    int menu_x = 250;
    int menu_y = 80;
    int door_x = 630;
    int door_y=  340;
 // Create a rectangle to represent the button
    SDL_Rect button_rect = {button_x,button_y, BUTTON_WIDTH, BUTTON_HEIGHT};

    // Create a rectangle to represent the menu
    SDL_Rect menu_rect = {menu_x,menu_y, MENU_WIDTH, MENU_HEIGHT};
// Create a rectangle to represent the door
SDL_Rect door_rect = {door_x,door_y, door_width, door_height};

    // Create a boolean variable to keep track of whether the menu is currently displayed
    bool menu_displayed = false;
	
    


int boucle=1;
int sucess;

    Personne p,p1;
TTF_Font *font = NULL;
    Uint32 dt,t_prev,t_fin;
    int acceleration=0,deceleration=0,up=0,up1=0,jump=0,acceleration1=0,deceleration1=0;
TTF_Init();
		if(TTF_Init() < 0)
    {
        printf("TTF initialization failed. TTF_Error: %s\n", TTF_GetError());
        
    }


   Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS, 1024);
	srand(time(NULL));
	Ennemi e1,e2;
	image tuto;




    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
    printf("SDL_Init Error: %s\n", SDL_GetError());
  
     }

SDL_Surface *screen = SDL_SetVideoMode(WIDTH,HEIGHT, 32, SDL_SWSURFACE);
if (screen == NULL) {
    printf("SDL_SetVideoMode Error: %s\n", SDL_GetError());
 
}

Mix_Music *music;
    Background background;
    initPerso(&p);
    initPerso2(&p1);
font = TTF_OpenFont("font.ttf", 20);
   	choice_player(&p, screen, font);
screen = SDL_SetVideoMode(WIDTH,HEIGHT, 32, SDL_SWSURFACE);
    // Initialize game tictactoe
    tictactoe_t tictactoe;
    init_tictactoe_assets();
    load_tictactoe(&tictactoe);
    ///////////////////////////
    init_map (&m);
    init_background(&background, screen);
    initialiser_temps(&t);
initialiser_score(&s);
    SDL_Rect *dot_rect;
    ///////////////////// musique continue/////////////////////////
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS, 1024);
    music = Mix_LoadMUS("music.mp3");
    Mix_PlayMusic(music, -1);
    ///////////////////////////////////////////////////////////////
    SDL_WM_SetCaption("----ESPRIT ESPRA----", NULL);

    int character_x = 100;
    int character_y = 100;
    int character_speed = 5;
   vie tli;
   score sc;
   int x, y;
    init_top_left_image(&tli, screen);

    bool quit = false;
Ennemi Ennemi;
	//initEnnemi(Ennemi, sprite sheet trajet, Ennemi sdl_rect coords(6 numbers),initial pos(x,y), number of pas);
	initEnnemi(&e1,"./animation/sheet.png",0,0,0,0,70,70,500,450,0,600,1,1);

	
while (!quit) {
    SDL_FillRect(screen, NULL, 0);
    const uint8_t *keys = SDL_GetKeyState(NULL);
   
    if (keys[SDLK_RIGHT]) {
        if (scrolling(screen, &background,1,character_x + character_speed, character_y,&anim)) {
        
                character_x += character_speed;
           
        }
else{

anim=0 ;} 
    }
    if (keys[SDLK_LEFT]) {
        if (scrolling(screen, &background, 2,character_x - character_speed, character_y,&anim)) {
         
                character_x -= character_speed;
            
        }
else{

anim=0 ;
} 
    }
    if (keys[SDLK_DOWN]) {
        if (scrolling(screen, &background, 4,character_x, character_y + character_speed,&anim)) {
                character_y += character_speed;
            
        }

    }
    if (keys[SDLK_UP]) {
        if (scrolling(screen, &background, 3,character_x, character_y - character_speed,&anim)) {
         
                character_y -= character_speed;
           
        }
    }
t_prev=SDL_GetTicks();
if(anim=1){
      draw_background(&background, screen,character_x,character_y,&tli,&anim);
}else 
background.img=IMG_Load("background_win.png");

SDL_BlitSurface(e1.sheet.img, &e1.sheet.posdisplay, screen, &e1.pos);
        SDL_Event event;
        while (SDL_PollEvent(&event))
        {
///////////////////////monojoueur//////////////////////////////////
	 if (p.num==1){
            switch (event.type)
            {

 case SDL_MOUSEBUTTONDOWN:
if (event.button.x >= door_x && event.button.x < door_x + door_width && event.button.y >= door_y && event.button.y < door_y + door_height) 
{
 SDL_Flip(screen);
win=true;
}
                    // Check if the user clicked on the button
                    if (event.button.x >= button_x && event.button.x < button_x + BUTTON_WIDTH && event.button.y >= button_y && event.button.y < button_y + BUTTON_HEIGHT) {
                        // Toggle the menu display
                        menu_displayed = !menu_displayed;
menu_image = load_image("menu_pause.png");
 menu_x=190; 
menu_y=90;
scoreB=0 ;
    SDL_Flip(screen);
                        printf("AA\n");
                    }
                // Check if the user clicked on the "Exit" button in the menu
                else if (menu_displayed && event.button.x >= 333 && event.button.x < 508 && event.button.y >= 423 && event.button.y < 508) {
                    // User clicked on the "Exit" button, exit the game
                    SDL_FreeSurface(button_image);
                    SDL_FreeSurface(menu_image);
                    SDL_Quit();
                    //return 0;
                }
                // Check if the user clicked on the "Next" button in the menu
                else if (menu_displayed && event.button.x >= 344 && event.button.x < 532 && event.button.y >= 158 && event.button.y < 239)
                        { 
                       printf("A\n");
                     // Load the new image
                     menu_image = load_image("score_board.png");
 menu_y=0; 
menu_x=90;
scoreB=1 ;
                     // User clicked on the "Next" button, do something
                     // For example, display the new image

                     SDL_Flip(screen);
                     // Hide the menu
                    
                    }

break;

                case SDL_QUIT:
			quit=true;
			break;
                    
                case SDL_KEYDOWN:
		    switch (event.key.keysym.sym)
		    {

			case SDLK_q:
                        case SDLK_ESCAPE:
                            quit = true;
                            break;
                        case SDLK_a:
                        tli.current_image = (tli.current_image + 1) % 5;
                    break;
                       case SDLK_b:
                        afficher_menu_pause(&background, screen);
                        SDL_Delay(50);
                      break;

		    case  SDLK_RIGHT:
			p.direction=0;
			p.vitesse=0.1;
			break;
		    case  SDLK_LEFT:
			p.direction=1;
			p.vitesse=0.1;
			break;
		    case SDLK_UP:
			up=1;
			break;  
		    case SDLK_o:
			acceleration=1;
		    break;
		    case SDLK_p:
			deceleration=1;
			break;		
		    case SDLK_SPACE:
			jump=1;
			break;
		case SDLK_x:
			
        		xo=TICTACTOE();
			SDL_Quit();
			break;
                   case SDLK_i:
			enigme_image();

			break;
		     case SDLK_t:
			
                      sucess=enig_fichier_avec_fichier();
			TTF_Quit();
			SDL_Quit();
			//enigme_image();
			break;
			}
		break;
                 case SDL_KEYUP:
			switch (event.key.keysym.sym)
			    {


			    case  SDLK_RIGHT:
				      p.vitesse=0;
				break;

			    case  SDLK_LEFT:        
				p.vitesse=0;
				break; 

			    case SDLK_UP:
				up=0;
				break; 

			    case SDLK_o:
				acceleration=0;
			    break;

			    case SDLK_p:
				deceleration=0;
				break;
			    case SDLK_SPACE:
				jump=0;
				break; 
				}
			break;
                default:
                    break;
            }
        }
////////////////////////multijoueur//////////////////////////
if (p.num==2)
    {
       switch (event.type)
{
case SDL_QUIT:
    quit=true;
    break;

case SDL_KEYDOWN:
    switch (event.key.keysym.sym)
    {
    case  SDLK_RIGHT:
        p.direction=0;
        p.vitesse=0.1;
        break;
    case  SDLK_LEFT:
        p.direction=1;
        p.vitesse=0.1;
        break;
    case SDLK_UP:
        up=1;
        break;  
    case SDLK_p:
        acceleration=1;
    break;
    case SDLK_o:
        deceleration=1;
        break;

       
    case  SDLK_d:
        p1.direction=0;
        p1.vitesse=0.1;
        break;
    case  SDLK_q:
        p1.direction=1;
        p1.vitesse=0.1;
        break;
    case SDLK_z:
        up1=1;
        break;  
    case SDLK_f:
        acceleration1=1;
    break;
    case SDLK_g:
        deceleration1=1;
        break;
   
    }
break;

case SDL_KEYUP:
switch (event.key.keysym.sym)//lbouton appuyé?
    {
    case  SDLK_RIGHT:
              p.vitesse=0;
        break;

    case  SDLK_LEFT:        
        p.vitesse=0;
        break;

    case SDLK_UP:
        up=0;
        break;

    case SDLK_p:
        acceleration=0;
    break;

    case SDLK_o:
        deceleration=0;
        break;

        case  SDLK_d:
              p1.vitesse=0;
        break;

    case  SDLK_q:        
        p1.vitesse=0;
        break;

    case SDLK_z:
        up1=0;
        break;

    case SDLK_f:
        acceleration1=0;
    break;

    case SDLK_g:
        deceleration1=0;
        break;
    case SDLK_ESCAPE:
	exit(1);
	break;            
   
    }

break;
}
}
        }


if (p.num==1){




    if (acceleration==1) 
		p.acceleration = p.acceleration + 0.005 ;
	if (deceleration==1) 
		p.acceleration = p.acceleration - 0.01;

	p.acceleration = p.acceleration - 0.001;
	if (p.acceleration<0) 
		p.acceleration =0;


	SDL_Delay(3);
	t_fin=SDL_GetTicks();
	dt=t_fin - t_prev ;
	deplacerPerso(&p,dt);
	animerPerso(&p);
draw_tag(&p,screen);

animerEnnemi(&e1,screen);
		
		move(&e1,100,p.position);

if (collisionBB(e1,p)==0 ){
printf("ok");
				attack(&e1);
				tli.current_image = (tli.current_image + 1) % 5;
init_background(&background, screen);
   initPerso(&p);
				//e2.nb_vie-=1; vie du perso --
		}
//e1.pos.y=450;
printf("%d",collisionBB(e1,p));
	if (up==1) 
{
SDL_Delay(50);
		saut(&p);
}
	if(jump==1)
{
		saut_Parabolique(&p,t_fin, 0,p.ground) ;
		animerPerso(&p);
		afficherPerso(p, screen);
}
	p.position.y = p.position.y   + p.vitesse_saut ;
	p.vitesse_saut = p.vitesse_saut + 10 ;
	if (p.position.y>=p.ground)
	{   
	    p.position.y=p.ground;
	    p.vitesse_saut=0;
	    p.up=0;
	}
	

	afficherPerso(p, screen);
	MAJMinimap(p.position,&m, camera, 60);
	afficherminimap(m,screen);
	draw_imagePAUSE(button_image,button_x,button_y);
	afficher_temps(&t,screen);
	afficher_score(&s,screen);
	////////tictactoe//////


     

if (menu_displayed)
                           draw_imagePAUSE(menu_image,menu_x,menu_y);
	   SDL_Flip(screen);

}   
if(win){
draw_imagePAUSE(door_image,door_x,door_y);
SDL_Flip(screen);
SDL_Delay(1000);
sucess=enig_fichier_avec_fichier();
			TTF_Quit();
			SDL_Quit();
lvl2=play_level2();


libererperso(p);
    libererperso(p1);
SDL_FreeSurface(e1.sheet.img);
    SDL_FreeSurface(screen);
SDL_FreeSurface(background.img);
SDL_FreeSurface(background.obstacle);
    SDL_FreeSurface(m.map);
    SDL_FreeSurface(door_image);
SDL_Flip(screen);
return 0;
}
    

//////////////////////////multijoueur////////////////////////
    if (p.num==2)
{
if (acceleration==1) 
	p.acceleration = p.acceleration + 0.005 ;
if (deceleration==1) 
	p.acceleration = p.acceleration - 0.01;

if (acceleration1==1) 
	p1.acceleration = p1.acceleration + 0.005 ;
if (deceleration1==1) 
	p1.acceleration = p1.acceleration - 0.01;

p.acceleration = p.acceleration - 0.001;
if (p.acceleration<0) 
	p.acceleration =0;


p1.acceleration = p1.acceleration - 0.001;
if (p1.acceleration<0) 
	p1.acceleration =0;


SDL_Delay(3);
t_fin=SDL_GetTicks();
dt=t_fin - t_prev ;
deplacerPerso(&p,dt);
deplacerPerso(&p1,dt);
animerPerso(&p);
animerPerso(&p1);
if (up1==1) saut(&p1);

if (up==1) saut(&p);
//printf("%f\n",p.vitesse_saut);
p.position.y = p.position.y   + p.vitesse_saut ;
p.vitesse_saut = p.vitesse_saut + 10 ;
if (p.position.y>=p.ground)
{  
    p.position.y=p.ground;
    p.vitesse_saut=0;
    p.up=0;
}

p1.position.y = p1.position.y   + p1.vitesse_saut ;
p1.vitesse_saut = p1.vitesse_saut + 10 ;
if (p1.position.y>=p1.ground)
{  
    p1.position.y=p1.ground;
    p1.vitesse_saut=0;
    p1.up=0;
}

}




//////////////////////////multijoueur////////////////////////
if (p.num==2)
{
    afficherPerso(p,screen);
    afficherPerso(p1,screen);
		MAJMinimap(p.position,&m, camera, 60);
	afficherminimap(m,screen);
	draw_imagePAUSE(button_image,button_x,button_y);
	afficher_temps(&t,screen);
if (menu_displayed)
                           draw_imagePAUSE(menu_image,menu_x,menu_y);
SDL_Flip(screen);
}
printf("%d",p.position.x);

}

    libererperso(p);
    libererperso(p1);
SDL_FreeSurface(e1.sheet.img);
    SDL_FreeSurface(screen);
SDL_FreeSurface(background.img);
SDL_FreeSurface(background.obstacle);
    SDL_FreeSurface(m.map);
    
    SDL_Quit();


       
        SDL_Delay(20);

      
    }

