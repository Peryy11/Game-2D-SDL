#ifndef MAIN_H_
#define MAIN_H_

#include "defs.h"
#include "tictactoe.h"


#define FONTSIZE 40

#endif // !MAIN_H_
