#include "tictactoe.h"

extern SDL_Surface *screen;

SDL_Surface *board;
SDL_Surface *x_img;
SDL_Surface *o_img;
TTF_Font *font;
int TICTACTOE()
{
    // Load SDL
    SDL_Init(SDL_INIT_VIDEO);
    TTF_Init();
    uint32_t flags = SDL_HWSURFACE | SDL_DOUBLEBUF;
    SDL_Surface *screen = SDL_SetVideoMode(460, 800, 0, flags);
int done=1;
    // Initialize game
    tictactoe_t tictactoe;
    init_tictactoe_assets();
    load_tictactoe(&tictactoe);

    // Game Loop
    while (done) {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            handle_input_tictactoe(event, &tictactoe);
	if(event.type==SDL_QUIT)
            done=0;
        }
        play_tictactoe(&tictactoe);
        draw_tictactoe(screen, tictactoe);
    }


    SDL_FreeSurface(screen);
    
    return EXIT_SUCCESS;
}
void die()
{
    fprintf(stderr, "%s\n", SDL_GetError());
    exit(-1);
}

void draw_imageX(SDL_Surface *screen, SDL_Surface *image, int x, int y)
{
    SDL_Rect dsrect = {.h=image->h, .w=image->w, .x=x, .y=y};
    SDL_BlitSurface(image, NULL, screen, &dsrect);
}

void render_textX(SDL_Surface *surface, TTF_Font *font,  const char *text, SDL_Color color, int x, int y)
{
	SDL_Rect titlepos;
	titlepos.x=x;
	titlepos.y=y;
	//title

	SDL_Surface *blended_text = TTF_RenderText_Blended(font, text, color);

    SDL_BlitSurface(blended_text, NULL, surface, &titlepos);
}

void init_tictactoe_assets()
{
    board = IMG_Load("board.png");
    x_img = IMG_Load("x.png");
    o_img = IMG_Load("o.png");
}

void load_tictactoe(tictactoe_t *tictactoe)
{
    tictactoe->state = RUNNING_STATE;
    tictactoe->player = PLAYER_X;

    font = TTF_OpenFont("font.ttf", 45);

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            tictactoe->board[i][j] = 0;
        }
    }
}

bool is_empty(const tictactoe_t tictactoe, int x, int y)
{
    if (tictactoe.board[x][y] == PLAYER_X || tictactoe.board[x][y] == PLAYER_O)
        return false;
    return true;
}

void switch_player(tictactoe_t *tictactoe)
{
    tictactoe->player = (tictactoe->player == PLAYER_X) ? PLAYER_O : PLAYER_X;
}

void check_row(tictactoe_t *tictactoe, int i, int px[3], int po[3])
{
    if (memcmp(&tictactoe->board[i], px, 3 * sizeof(int)) == 0)
        tictactoe->state = X_WON_STATE;
    else if (memcmp(&tictactoe->board[i], po, 3 * sizeof(int)) == 0)
        tictactoe->state = O_WON_STATE;
}

void check_col(tictactoe_t *tictactoe, int j, int px[3], int po[3])
{
    int cells[3];
    for (int i = 0; i < 3; i++)
        cells[i] = tictactoe->board[i][j];

    if (memcmp(cells, px, 3 * sizeof(int)) == 0)
        tictactoe->state = X_WON_STATE;
    else if (memcmp(cells, po, 3 * sizeof(int)) == 0)
        tictactoe->state = O_WON_STATE;
}

void check_diagonal_r(tictactoe_t *tictactoe, int px[3], int po[3])
{
    int cells[3];
    for (int i = 0; i < 3; i++) {
        cells[i] = tictactoe->board[i][i];
    }

    if (memcmp(cells, px, 3 * sizeof(int)) == 0)
        tictactoe->state = X_WON_STATE;
    else if (memcmp(cells, po, 3 * sizeof(int)) == 0)
        tictactoe->state = O_WON_STATE;
}

void check_diagonal_l(tictactoe_t *tictactoe, int px[3], int po[3])
{
    int cells[3];
    for (int i = 2; i >= 0; i--) {
        cells[i] = tictactoe->board[2 - i][i];
    }

    if (memcmp(cells, px, 3 * sizeof(int)) == 0)
        tictactoe->state = X_WON_STATE;
    else if (memcmp(cells, po, 3 * sizeof(int)) == 0)
        tictactoe->state = O_WON_STATE;
}

void check_win(tictactoe_t *tictactoe)
{
    int px[3] = {PLAYER_X, PLAYER_X, PLAYER_X};
    int po[3] = {PLAYER_O, PLAYER_O, PLAYER_O};

    int i = 0;
    while (tictactoe->state == RUNNING_STATE && i < 3) {
        check_row(tictactoe, i, px, po);
        check_col(tictactoe, i, px, po);
        check_diagonal_r(tictactoe, px, po);
        check_diagonal_l(tictactoe, px, po);

        i++;
    }
}

void check_tie(tictactoe_t *tictactoe)
{
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (is_empty(*tictactoe, j, i) == true)
                return;
        }
    }

    tictactoe->state = TIE_STATE;
}

void check_state(tictactoe_t *tictactoe)
{
    check_win(tictactoe);
    if (tictactoe->state == RUNNING_STATE)
        check_tie(tictactoe);
}

void bot(tictactoe_t *tictactoe)
{
    if (tictactoe->state != RUNNING_STATE)
        return;

    int i, j;
    do {
        i = rand() % 3;
        j = rand() % 3;
    }while(is_empty(*tictactoe, i, j) == false);

    tictactoe->board[i][j] = PLAYER_O;
    switch_player(tictactoe);
}


void draw_board(SDL_Surface *screen, tictactoe_t tictactoe)
{
    draw_imageX(screen, board, 0, 0);
    uint xpos_on_screen, ypos_on_screen;

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            xpos_on_screen = 40 + (130 * j);
            ypos_on_screen = 265 + (133 * i);

            switch (tictactoe.board[i][j]) {
                case 1:
                    draw_imageX(screen, x_img, xpos_on_screen, ypos_on_screen);
                    break;
                case 2:
                    draw_imageX(screen, o_img, xpos_on_screen, ypos_on_screen);
                    break;
                default: {}
            }
        }
    }
}

void draw_tictactoe(SDL_Surface *screen, tictactoe_t tictactoe)
{
    SDL_FillRect(screen, NULL, 0);
    draw_board(screen, tictactoe);

    SDL_Color color;

    color.r = 255; color.g = 255; color.b = 255;
    render_textX(screen, font, "R: Replay", color, 50, 740);

    switch (tictactoe.state) {
        case X_WON_STATE:
            color.r = 255; color.g = 255; color.b = 255;
            render_textX(screen, font, "YOU WON", color, 40, 20);
            break;
        case O_WON_STATE:
            color.r = 255; color.g = 255; color.b = 255;
            render_textX(screen, font, "YOU LOST", color, 40, 20);
            break;
        case TIE_STATE:
            color.r = 255; color.g = 255; color.b = 255;
            render_textX(screen, font, "TIE", color, 40, 20);
            break;
        default: {}
    }

    SDL_Flip(screen);
    SDL_Delay(60);
}

void handle_mouseevent_tictactoe(SDL_Event event, tictactoe_t *tictactoe)
{
    int x, y;
    x = event.button.x / 160;
    y = (event.button.y / 130) - 2;
    if (x >= 0 && x <= 2 && y >= 0 && y <= 2 && is_empty(*tictactoe, y, x)) {
        if (tictactoe->player == PLAYER_X)
            tictactoe->board[y][x] = PLAYER_X;
        else
            tictactoe->board[y][x] = PLAYER_O;

        switch_player(tictactoe);
    }
}

void handle_input_tictactoe(SDL_Event event, tictactoe_t *tictactoe)
{
    switch (event.type) {
        case SDL_QUIT:
            tictactoe->state = QUIT_STATE;
            break;
        case SDL_KEYDOWN:
            switch (event.key.keysym.sym) {
                case SDLK_ESCAPE:
                case SDLK_q:
                    tictactoe->state = QUIT_STATE;
                    break;
                case SDLK_r:
                    load_tictactoe(tictactoe);
                default: {}
            }
        case SDL_MOUSEBUTTONDOWN:
            if (tictactoe->state == RUNNING_STATE && tictactoe->player == PLAYER_X) {
                handle_mouseevent_tictactoe(event, tictactoe);
            }
        default: {}
    }
}

void play_tictactoe(tictactoe_t *tictactoe)
{
    check_state(tictactoe);

    if (tictactoe->player == PLAYER_O) {
        bot(tictactoe);
    }
}
