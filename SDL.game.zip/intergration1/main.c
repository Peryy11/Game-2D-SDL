#include<stdio.h>
#include<stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include "fichier.h"
#include "sauvgarder.h"
#include "perso.h"
#include "function.h"

int main ()
{
SDL_Surface *screen;
int volume,m=0,game;
Mix_Music *music;
volume=initialiser_audio(music);
Personne p;
Background b;
//minimap m;
game=menu(volume,screen,m);
switch(game)
{
case 1:
	sauvegarder (p,b);
	break;
case 2:
	charger (&p,&b);
			break;
}
	
liberer_musique(music);

SDL_Quit();

return 0;


}


