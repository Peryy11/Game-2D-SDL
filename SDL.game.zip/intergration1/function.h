#ifndef FUNCTION_H_
#define FUNCTION_H_

#include <stdint.h>
#include <stdio.h>
#include <stdbool.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>

typedef struct {
int offset_x;
int offset_y;
int offset_val;
SDL_Rect srect,pause_pos,score_pos;
SDL_Rect dsrect;
SDL_Surface *img,*pause,*score;
SDL_Surface *obstacle;
} Background;

typedef struct {
    int current_image;
    SDL_Surface *images[5];
    SDL_Rect position;
} vie;
typedef struct {
    int current_image;
    SDL_Surface *img[2];
    SDL_Rect position;
}imgscore;
typedef struct score
{
 SDL_Surface *texte;//image qui contient le score
 SDL_Rect position;// position
 TTF_Font *police ;
 char entree[100]; // chaine de caractere . forme "score:"
 int secondesEcoulees; // variable entier qui contient le nbre de secondes ecoulés
 SDL_Color couleurn;// couleur de texte a afficher
 time_t t1,t2; //t1 temps initiale ,,, t2 temps actuel
 int sc;// minutes et secondes
}score;
#define OFFSET_VAL 5

void init_background(Background *b, SDL_Surface *screen);
void init_background_level2(Background *b, SDL_Surface *screen);
void init_background_level3(Background *b, SDL_Surface *screen);
void draw_background(Background *b, SDL_Surface *screen, int x, int y,vie *tli,int *anim);
bool scrolling(SDL_Surface *screen, Background *b, int direction, int x, int y,int *anim);
bool is_collision(SDL_Surface *screen, Background *b, int x, int y);
void afficher_menu_pause(Background *b, SDL_Surface *screen);
void animate_background(Background *b);
void animate_background_lvl2(Background *b) ;
void animate_background_lvl3(Background *b) ;
void init_top_left_image(vie *tli, SDL_Surface *screen);
void score_menu(imgscore *tli, SDL_Surface *screen);
void draw_background_lvl2(Background *b, SDL_Surface *screen, int x, int y,vie *tli,int *anim);
void draw_background_lvl3(Background *b, SDL_Surface *screen, int x, int y,vie *tli,int *anim);
void initialiser_score(score *s);
void afficher_score(score *s, SDL_Surface *screen);
SDL_Surface* load_image(const char* filename);
void draw_imagePAUSE(SDL_Surface* image, int x, int y);
void draw_background_lvl3(Background *b, SDL_Surface *screen, int x, int y,vie *tli,int *anim) ;
#endif // !FUNCTION_H_
