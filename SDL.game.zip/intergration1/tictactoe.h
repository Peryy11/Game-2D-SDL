#ifndef TICTACTOE_H_
#define TICTACTOE_H_

#include "defs.h"


#define N 3

#define PLAYER_X 1
#define PLAYER_O 2

enum {
    RUNNING_STATE,
    X_WON_STATE,
    O_WON_STATE,
    TIE_STATE,
    QUIT_STATE,
};

typedef struct {
    int board[N][N];
    int player;
    int state;
}tictactoe_t;

void draw_imageX(SDL_Surface *screen, SDL_Surface *image, int x, int y);
void init_tictactoe_assets();
void load_tictactoe(tictactoe_t *tictactoe);
bool is_empty(const tictactoe_t tictactoe, int x, int y);
void switch_player(tictactoe_t *tictactoe);
void check_row(tictactoe_t *tictactoe, int i, int px[3], int po[3]);
void check_col(tictactoe_t *tictactoe, int j, int px[3], int po[3]);
void check_diagonal_r(tictactoe_t *tictactoe, int px[3], int po[3]);
void check_diagonal_l(tictactoe_t *tictactoe, int px[3], int po[3]);
void check_win(tictactoe_t *tictactoe);
void check_win(tictactoe_t *tictactoe);
void check_tie(tictactoe_t *tictactoe);
void check_state(tictactoe_t *tictactoe);
void bot(tictactoe_t *tictactoe);
void draw_board(SDL_Surface *screen, tictactoe_t tictactoe);
void draw_tictactoe(SDL_Surface *screen, tictactoe_t tictactoe);
void handle_mouseevent_tictactoe(SDL_Event event, tictactoe_t *tictactoe);
void handle_input_tictactoe(SDL_Event event, tictactoe_t *tictactoe);
void play_tictactoe(tictactoe_t *tictactoe);
int TICTACTOE();
#endif //TICTACTOE_H_
