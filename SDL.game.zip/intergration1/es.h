#ifndef HEADERS_H
#define HEADERS_H
#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include <time.h>
#include"perso.h"

typedef struct{
	SDL_Rect posdisplay;
	SDL_Rect posscreen;
	SDL_Surface *img;
}image;
typedef struct {
	image sheet;
	SDL_Rect pos;
	int direction, pas,xi,yi;
	int marche,vitesse, nb_vie, range;
	Uint32 etat_animation;
}Ennemi;


void initEnnemi(Ennemi *e, char* trajet, int x, int y, int a, int b, int h, int w, int x1, int y1,int pas, int range, int vitesse, int vie);
void animerEnnemi(Ennemi *e,SDL_Surface *screen);
void move(Ennemi *en, int pas, SDL_Rect pos);
int collisionBB(Ennemi e1, Personne e2);
void attack(Ennemi *e);
void afficher(SDL_Surface *img, SDL_Surface *screen, int x, int y);
void musique();
int in_range(SDL_Rect pos, Ennemi en);
void follow(Ennemi *en, SDL_Rect pos);
void reset(Ennemi *e);
#endif 
